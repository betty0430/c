﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace lift
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            A_1.Checked = true;
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
            //big = 1;
            //smail = 1;

            close.Checked = true;
        }
        //決定上下樓
        int q = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            close.Checked = true;
            number = int.Parse(comboBox1.Text);
            if (number > light_mg)
            {
                q = 1; closept();
            }
            else if (number < light_mg)
            {
                q = -1; closept();
            }
            number = 0;

            //groupBox1.Enabled = false;
        }
        //電梯停樓層
        int light_mg = 1;
        //要搭的樓層
        int number;

        //上還是下
        bool up_start = false;
        bool bown_start = false;
        //上下樓
        private void up_bown_Click(object sender, EventArgs e)
        {
            Button bt = sender as Button;
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("請選擇樓層","警示");
            }
            else
            {
                bt.BackColor = Color.White;
                if (bt.Text == "▲")
                {
                    bown_start = false;
                    up_start = true;
                }
                else
                {
                    bown_start = true;
                    up_start = false;
                }
                groupBox2.Enabled = true;
                open.Checked = true;
            }
        }


        //電梯所在樓層到某樓(b)
        int m = 0;
        private void light_go(int b)
        {
            //電梯所在樓層light_mg
            if (light_mg < b)
            {
                m = 1;//上
                up_light.Checked = true;
            }
            else
            {
                m = -1;//下
                bown_light.Checked = true;
            }

            for (int c = light_mg; ; c += m)
            {
                System.Threading.Thread.Sleep(1000);
                //顯示
                switch (c)
                {
                    case 1:
                        A_1.Checked = true;
                        if (RB_1.Checked == true)
                        {
                            RB_1.Checked = false;
                            open.Checked=true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 2:
                        A_2.Checked = true;
                        if (RB_2.Checked == true)
                        {
                            RB_2.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 3:
                        A_3.Checked = true;
                        if (RB_3.Checked == true)
                        {
                            RB_3.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 4:
                        A_4.Checked = true;
                        if (RB_4.Checked == true)
                        {
                            RB_4.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 5:
                        A_5.Checked = true;
                        if (RB_5.Checked == true)
                        {
                            RB_5.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 6:
                        A_6.Checked = true;
                        if (RB_6.Checked == true)
                        {
                            RB_6.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 7:
                        A_7.Checked = true;
                        if (RB_7.Checked == true)
                        {
                            RB_7.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 8:
                        A_8.Checked = true;
                        if (RB_8.Checked == true)
                        {
                            RB_8.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                }
                if (light_mg == b)
                {
                    up_light.Checked = false;
                    bown_light.Checked = false;
                    close.Checked = true;
                    return;
                }
                light_mg += m;
            }
        }

        //int big;
        //int smail;
        private void close_CheckedChanged(object sender, EventArgs e)
        {
            up.BackColor = Color.Silver;
            bown.BackColor = Color.Silver;
            if (close.Checked == true)
            {
                if (up_start == true)
                {
                    up_start = false;
                    q = 1;
                    closept();
                    q = -1;
                    closept();

                    groupBox1.Enabled = true;
                    groupBox2.Enabled = false;
                    close.Checked = true;

                }
                if (bown_start == true)
                {
                    bown_start = false;
                    q = -1;
                    closept(); 
                    q = 1;
                    closept();

                    groupBox1.Enabled = true;
                    groupBox2.Enabled = false;
                    close.Checked = true;

                }
            }
        }

        private void closept()
        {
            for (int c = light_mg; c <= 8 && c >= 1; c += q)
            {
                switch (c)
                {
                    case 1:
                        if (RB_1.Checked == true || number == 1)
                        {
                            light_go(c);
                        }
                        break;
                    case 2:
                        if (RB_2.Checked == true || number == 2)
                        {
                            light_go(c);
                        }
                        break;
                    case 3:
                        if (RB_3.Checked == true || number == 3)
                        {
                            light_go(c);
                        }
                        break;
                    case 4:
                        if (RB_4.Checked == true || number == 4)
                        {
                            light_go(c);
                        }
                        break;
                    case 5:
                        if (RB_5.Checked == true || number == 5)
                        {
                            light_go(c);
                        }
                        break;
                    case 6:
                        if (RB_6.Checked == true || number == 6)
                        {
                            light_go(c);
                        }
                        break;
                    case 7:
                        if (RB_7.Checked == true || number == 7)
                        {
                            light_go(c);
                        }
                        break;
                    case 8:
                        if (RB_8.Checked == true || number == 8)
                        {
                            light_go(c);
                        }
                        break;
                }
            }
        }

        
        private void RB_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (int.Parse(rb.Text) != light_mg) rb.Checked = !rb.Checked;
            //if (big < int.Parse(rb.Text)) big = int.Parse(rb.Text);
            //if (smail > int.Parse(rb.Text)) smail = int.Parse(rb.Text);
        }

        private void open_CheckedChanged(object sender, EventArgs e)
        {
            if (open.Checked == true)
            {
                up_light.Checked = false;
                bown_light.Checked = false;
            }
        }
    }
}
