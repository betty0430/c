﻿namespace lift
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.show_out = new System.Windows.Forms.Label();
            this.bown = new System.Windows.Forms.Button();
            this.up = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.close = new System.Windows.Forms.RadioButton();
            this.open = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RB_8 = new System.Windows.Forms.RadioButton();
            this.RB_7 = new System.Windows.Forms.RadioButton();
            this.RB_6 = new System.Windows.Forms.RadioButton();
            this.RB_5 = new System.Windows.Forms.RadioButton();
            this.RB_4 = new System.Windows.Forms.RadioButton();
            this.RB_3 = new System.Windows.Forms.RadioButton();
            this.RB_2 = new System.Windows.Forms.RadioButton();
            this.RB_1 = new System.Windows.Forms.RadioButton();
            this.show_in = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.A_8 = new System.Windows.Forms.RadioButton();
            this.A_1 = new System.Windows.Forms.RadioButton();
            this.A_7 = new System.Windows.Forms.RadioButton();
            this.A_2 = new System.Windows.Forms.RadioButton();
            this.A_6 = new System.Windows.Forms.RadioButton();
            this.A_3 = new System.Windows.Forms.RadioButton();
            this.A_5 = new System.Windows.Forms.RadioButton();
            this.A_4 = new System.Windows.Forms.RadioButton();
            this.up_light = new System.Windows.Forms.RadioButton();
            this.bown_light = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.show_out);
            this.groupBox1.Controls.Add(this.bown);
            this.groupBox1.Controls.Add(this.up);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 12F);
            this.groupBox1.Location = new System.Drawing.Point(71, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 466);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "電梯外";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBox1.Location = new System.Drawing.Point(6, 376);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(228, 28);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.Text = "請選擇目前所在樓層";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // show_out
            // 
            this.show_out.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.show_out.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.show_out.Location = new System.Drawing.Point(77, 42);
            this.show_out.Name = "show_out";
            this.show_out.Size = new System.Drawing.Size(95, 173);
            this.show_out.TabIndex = 2;
            this.show_out.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bown
            // 
            this.bown.BackColor = System.Drawing.Color.Silver;
            this.bown.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bown.Location = new System.Drawing.Point(76, 312);
            this.bown.Name = "bown";
            this.bown.Size = new System.Drawing.Size(96, 43);
            this.bown.TabIndex = 1;
            this.bown.Text = "▼";
            this.bown.UseVisualStyleBackColor = false;
            this.bown.Click += new System.EventHandler(this.up_bown_Click);
            // 
            // up
            // 
            this.up.BackColor = System.Drawing.Color.Silver;
            this.up.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.up.Location = new System.Drawing.Point(76, 237);
            this.up.Name = "up";
            this.up.Size = new System.Drawing.Size(91, 48);
            this.up.TabIndex = 0;
            this.up.Text = "▲";
            this.up.UseVisualStyleBackColor = false;
            this.up.Click += new System.EventHandler(this.up_bown_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox2.Controls.Add(this.close);
            this.groupBox2.Controls.Add(this.open);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.show_in);
            this.groupBox2.Font = new System.Drawing.Font("新細明體", 12F);
            this.groupBox2.Location = new System.Drawing.Point(464, 128);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(285, 466);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "電梯內";
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.Font = new System.Drawing.Font("新細明體", 14F);
            this.close.Location = new System.Drawing.Point(146, 402);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(55, 28);
            this.close.TabIndex = 9;
            this.close.TabStop = true;
            this.close.Text = "關";
            this.close.UseVisualStyleBackColor = true;
            this.close.CheckedChanged += new System.EventHandler(this.close_CheckedChanged);
            // 
            // open
            // 
            this.open.AutoSize = true;
            this.open.Font = new System.Drawing.Font("新細明體", 14F);
            this.open.Location = new System.Drawing.Point(86, 402);
            this.open.Name = "open";
            this.open.Size = new System.Drawing.Size(55, 28);
            this.open.TabIndex = 8;
            this.open.TabStop = true;
            this.open.Text = "開";
            this.open.UseVisualStyleBackColor = true;
            this.open.CheckedChanged += new System.EventHandler(this.open_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.RB_8);
            this.panel1.Controls.Add(this.RB_7);
            this.panel1.Controls.Add(this.RB_6);
            this.panel1.Controls.Add(this.RB_5);
            this.panel1.Controls.Add(this.RB_4);
            this.panel1.Controls.Add(this.RB_3);
            this.panel1.Controls.Add(this.RB_2);
            this.panel1.Controls.Add(this.RB_1);
            this.panel1.Location = new System.Drawing.Point(61, 214);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(162, 173);
            this.panel1.TabIndex = 4;
            // 
            // RB_8
            // 
            this.RB_8.AutoCheck = false;
            this.RB_8.AutoSize = true;
            this.RB_8.Location = new System.Drawing.Point(89, 14);
            this.RB_8.Name = "RB_8";
            this.RB_8.Size = new System.Drawing.Size(39, 24);
            this.RB_8.TabIndex = 7;
            this.RB_8.TabStop = true;
            this.RB_8.Text = "8";
            this.RB_8.UseVisualStyleBackColor = true;
            this.RB_8.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_7
            // 
            this.RB_7.AutoCheck = false;
            this.RB_7.AutoSize = true;
            this.RB_7.Location = new System.Drawing.Point(89, 57);
            this.RB_7.Name = "RB_7";
            this.RB_7.Size = new System.Drawing.Size(39, 24);
            this.RB_7.TabIndex = 6;
            this.RB_7.TabStop = true;
            this.RB_7.Text = "7";
            this.RB_7.UseVisualStyleBackColor = true;
            this.RB_7.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_6
            // 
            this.RB_6.AutoCheck = false;
            this.RB_6.AutoSize = true;
            this.RB_6.Location = new System.Drawing.Point(89, 98);
            this.RB_6.Name = "RB_6";
            this.RB_6.Size = new System.Drawing.Size(39, 24);
            this.RB_6.TabIndex = 5;
            this.RB_6.TabStop = true;
            this.RB_6.Text = "6";
            this.RB_6.UseVisualStyleBackColor = true;
            this.RB_6.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_5
            // 
            this.RB_5.AutoCheck = false;
            this.RB_5.AutoSize = true;
            this.RB_5.Location = new System.Drawing.Point(89, 138);
            this.RB_5.Name = "RB_5";
            this.RB_5.Size = new System.Drawing.Size(39, 24);
            this.RB_5.TabIndex = 4;
            this.RB_5.TabStop = true;
            this.RB_5.Text = "5";
            this.RB_5.UseVisualStyleBackColor = true;
            this.RB_5.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_4
            // 
            this.RB_4.AutoCheck = false;
            this.RB_4.AutoSize = true;
            this.RB_4.Location = new System.Drawing.Point(29, 14);
            this.RB_4.Name = "RB_4";
            this.RB_4.Size = new System.Drawing.Size(39, 24);
            this.RB_4.TabIndex = 3;
            this.RB_4.TabStop = true;
            this.RB_4.Text = "4";
            this.RB_4.UseVisualStyleBackColor = true;
            this.RB_4.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_3
            // 
            this.RB_3.AutoCheck = false;
            this.RB_3.AutoSize = true;
            this.RB_3.Location = new System.Drawing.Point(29, 57);
            this.RB_3.Name = "RB_3";
            this.RB_3.Size = new System.Drawing.Size(39, 24);
            this.RB_3.TabIndex = 2;
            this.RB_3.TabStop = true;
            this.RB_3.Text = "3";
            this.RB_3.UseVisualStyleBackColor = true;
            this.RB_3.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_2
            // 
            this.RB_2.AutoCheck = false;
            this.RB_2.AutoSize = true;
            this.RB_2.Location = new System.Drawing.Point(29, 98);
            this.RB_2.Name = "RB_2";
            this.RB_2.Size = new System.Drawing.Size(39, 24);
            this.RB_2.TabIndex = 1;
            this.RB_2.TabStop = true;
            this.RB_2.Text = "2";
            this.RB_2.UseVisualStyleBackColor = true;
            this.RB_2.Click += new System.EventHandler(this.RB_Click);
            // 
            // RB_1
            // 
            this.RB_1.AutoCheck = false;
            this.RB_1.AutoSize = true;
            this.RB_1.Location = new System.Drawing.Point(29, 138);
            this.RB_1.Name = "RB_1";
            this.RB_1.Size = new System.Drawing.Size(44, 24);
            this.RB_1.TabIndex = 0;
            this.RB_1.TabStop = true;
            this.RB_1.Text = " 1";
            this.RB_1.UseVisualStyleBackColor = true;
            this.RB_1.Click += new System.EventHandler(this.RB_Click);
            // 
            // show_in
            // 
            this.show_in.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.show_in.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.show_in.Location = new System.Drawing.Point(90, 42);
            this.show_in.Name = "show_in";
            this.show_in.Size = new System.Drawing.Size(95, 160);
            this.show_in.TabIndex = 3;
            this.show_in.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.A_8);
            this.groupBox3.Controls.Add(this.A_1);
            this.groupBox3.Controls.Add(this.A_7);
            this.groupBox3.Controls.Add(this.A_2);
            this.groupBox3.Controls.Add(this.A_6);
            this.groupBox3.Controls.Add(this.A_3);
            this.groupBox3.Controls.Add(this.A_5);
            this.groupBox3.Controls.Add(this.A_4);
            this.groupBox3.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(129, 32);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(620, 60);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "電梯所在樓層";
            // 
            // A_8
            // 
            this.A_8.AutoSize = true;
            this.A_8.Location = new System.Drawing.Point(566, 28);
            this.A_8.Name = "A_8";
            this.A_8.Size = new System.Drawing.Size(40, 23);
            this.A_8.TabIndex = 15;
            this.A_8.TabStop = true;
            this.A_8.Text = "8";
            this.A_8.UseVisualStyleBackColor = true;
            // 
            // A_1
            // 
            this.A_1.AutoSize = true;
            this.A_1.Location = new System.Drawing.Point(25, 28);
            this.A_1.Name = "A_1";
            this.A_1.Size = new System.Drawing.Size(46, 23);
            this.A_1.TabIndex = 8;
            this.A_1.TabStop = true;
            this.A_1.Text = " 1";
            this.A_1.UseVisualStyleBackColor = true;
            // 
            // A_7
            // 
            this.A_7.AutoSize = true;
            this.A_7.Location = new System.Drawing.Point(490, 28);
            this.A_7.Name = "A_7";
            this.A_7.Size = new System.Drawing.Size(40, 23);
            this.A_7.TabIndex = 14;
            this.A_7.TabStop = true;
            this.A_7.Text = "7";
            this.A_7.UseVisualStyleBackColor = true;
            // 
            // A_2
            // 
            this.A_2.AutoSize = true;
            this.A_2.Location = new System.Drawing.Point(110, 28);
            this.A_2.Name = "A_2";
            this.A_2.Size = new System.Drawing.Size(40, 23);
            this.A_2.TabIndex = 9;
            this.A_2.TabStop = true;
            this.A_2.Text = "2";
            this.A_2.UseVisualStyleBackColor = true;
            // 
            // A_6
            // 
            this.A_6.AutoSize = true;
            this.A_6.Location = new System.Drawing.Point(414, 28);
            this.A_6.Name = "A_6";
            this.A_6.Size = new System.Drawing.Size(40, 23);
            this.A_6.TabIndex = 13;
            this.A_6.TabStop = true;
            this.A_6.Text = "6";
            this.A_6.UseVisualStyleBackColor = true;
            // 
            // A_3
            // 
            this.A_3.AutoSize = true;
            this.A_3.Location = new System.Drawing.Point(186, 28);
            this.A_3.Name = "A_3";
            this.A_3.Size = new System.Drawing.Size(40, 23);
            this.A_3.TabIndex = 10;
            this.A_3.TabStop = true;
            this.A_3.Text = "3";
            this.A_3.UseVisualStyleBackColor = true;
            // 
            // A_5
            // 
            this.A_5.AutoSize = true;
            this.A_5.Location = new System.Drawing.Point(338, 28);
            this.A_5.Name = "A_5";
            this.A_5.Size = new System.Drawing.Size(40, 23);
            this.A_5.TabIndex = 12;
            this.A_5.TabStop = true;
            this.A_5.Text = "5";
            this.A_5.UseVisualStyleBackColor = true;
            // 
            // A_4
            // 
            this.A_4.AutoSize = true;
            this.A_4.Location = new System.Drawing.Point(262, 28);
            this.A_4.Name = "A_4";
            this.A_4.Size = new System.Drawing.Size(40, 23);
            this.A_4.TabIndex = 11;
            this.A_4.TabStop = true;
            this.A_4.Text = "4";
            this.A_4.UseVisualStyleBackColor = true;
            // 
            // up_light
            // 
            this.up_light.AutoSize = true;
            this.up_light.Location = new System.Drawing.Point(71, 43);
            this.up_light.Name = "up_light";
            this.up_light.Size = new System.Drawing.Size(43, 19);
            this.up_light.TabIndex = 9;
            this.up_light.TabStop = true;
            this.up_light.Text = "▲";
            this.up_light.UseVisualStyleBackColor = true;
            // 
            // bown_light
            // 
            this.bown_light.AutoSize = true;
            this.bown_light.Location = new System.Drawing.Point(71, 83);
            this.bown_light.Name = "bown_light";
            this.bown_light.Size = new System.Drawing.Size(47, 19);
            this.bown_light.TabIndex = 10;
            this.bown_light.TabStop = true;
            this.bown_light.Text = "▼ ";
            this.bown_light.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 618);
            this.Controls.Add(this.bown_light);
            this.Controls.Add(this.up_light);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "電梯";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label show_out;
        private System.Windows.Forms.Button bown;
        private System.Windows.Forms.Button up;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RB_6;
        private System.Windows.Forms.RadioButton RB_5;
        private System.Windows.Forms.RadioButton RB_2;
        private System.Windows.Forms.RadioButton RB_1;
        private System.Windows.Forms.Label show_in;
        private System.Windows.Forms.RadioButton RB_4;
        private System.Windows.Forms.RadioButton RB_3;
        private System.Windows.Forms.RadioButton RB_8;
        private System.Windows.Forms.RadioButton RB_7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton A_8;
        private System.Windows.Forms.RadioButton A_1;
        private System.Windows.Forms.RadioButton A_7;
        private System.Windows.Forms.RadioButton A_2;
        private System.Windows.Forms.RadioButton A_6;
        private System.Windows.Forms.RadioButton A_3;
        private System.Windows.Forms.RadioButton A_5;
        private System.Windows.Forms.RadioButton A_4;
        private System.Windows.Forms.RadioButton close;
        private System.Windows.Forms.RadioButton open;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton up_light;
        private System.Windows.Forms.RadioButton bown_light;
    }
}

