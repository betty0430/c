﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _20200919練習
{
    class Program
    {
        static void Main(string[] args)
        {
            PT p = new PT();
            while (true)
            {
                try
                {
                    checked
                    {
                        int x = int.Parse(Console.ReadLine());
                        string[] y = Console.ReadLine().Split(' ');
                        for(int pt = 0; pt <= x-1; pt++)
                        {
                            p.n6(uint.Parse(y[pt]));
                            Console.WriteLine($"{p.v}");
                            p.v = 1;
                        }
                    }
                }
                catch (Exception q)
                {
                    Console.WriteLine(q);
                }
                finally
                {

                }
            }
        }
    }
}