﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.STnum = new System.Windows.Forms.TextBox();
            this.all = new System.Windows.Forms.Button();
            this.english = new System.Windows.Forms.Button();
            this.CLB = new System.Windows.Forms.CheckedListBox();
            this.Change_people = new System.Windows.Forms.Label();
            this.big = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Button();
            this.sotring = new System.Windows.Forms.Button();
            this.smail = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.CLB);
            this.groupBox1.Controls.Add(this.english);
            this.groupBox1.Controls.Add(this.all);
            this.groupBox1.Controls.Add(this.STnum);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 12F);
            this.groupBox1.Location = new System.Drawing.Point(27, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(418, 522);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "模擬產生姓名與成績";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.listBox2);
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.smail);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.sotring);
            this.panel1.Controls.Add(this.big);
            this.panel1.Controls.Add(this.Change_people);
            this.panel1.Font = new System.Drawing.Font("新細明體", 12F);
            this.panel1.Location = new System.Drawing.Point(546, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 660);
            this.panel1.TabIndex = 1;
            // 
            // STnum
            // 
            this.STnum.Location = new System.Drawing.Point(22, 43);
            this.STnum.Name = "STnum";
            this.STnum.Size = new System.Drawing.Size(100, 31);
            this.STnum.TabIndex = 0;
            this.STnum.TextChanged += new System.EventHandler(this.STnum_TextChanged);
            // 
            // all
            // 
            this.all.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.all.Location = new System.Drawing.Point(137, 43);
            this.all.Name = "all";
            this.all.Size = new System.Drawing.Size(86, 31);
            this.all.TabIndex = 1;
            this.all.Text = "全選";
            this.all.UseVisualStyleBackColor = false;
            this.all.Click += new System.EventHandler(this.all_Click);
            // 
            // english
            // 
            this.english.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.english.Location = new System.Drawing.Point(253, 43);
            this.english.Name = "english";
            this.english.Size = new System.Drawing.Size(134, 31);
            this.english.TabIndex = 2;
            this.english.Text = "英文>=60";
            this.english.UseVisualStyleBackColor = false;
            this.english.Click += new System.EventHandler(this.english_Click);
            // 
            // CLB
            // 
            this.CLB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.CLB.CheckOnClick = true;
            this.CLB.ForeColor = System.Drawing.Color.Black;
            this.CLB.FormattingEnabled = true;
            this.CLB.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.CLB.Location = new System.Drawing.Point(22, 101);
            this.CLB.Name = "CLB";
            this.CLB.ScrollAlwaysVisible = true;
            this.CLB.Size = new System.Drawing.Size(365, 394);
            this.CLB.TabIndex = 3;
            this.CLB.SelectedIndexChanged += new System.EventHandler(this.CLB_SelectedIndexChanged);
            // 
            // Change_people
            // 
            this.Change_people.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Change_people.Location = new System.Drawing.Point(25, 28);
            this.Change_people.Name = "Change_people";
            this.Change_people.Size = new System.Drawing.Size(103, 31);
            this.Change_people.TabIndex = 0;
            this.Change_people.Text = "挑選人數";
            this.Change_people.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // big
            // 
            this.big.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.big.Location = new System.Drawing.Point(213, 28);
            this.big.Name = "big";
            this.big.Size = new System.Drawing.Size(125, 31);
            this.big.TabIndex = 1;
            this.big.Text = "最高分者";
            this.big.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.delete.Location = new System.Drawing.Point(29, 334);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(86, 31);
            this.delete.TabIndex = 4;
            this.delete.Text = "移除";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // sotring
            // 
            this.sotring.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.sotring.Location = new System.Drawing.Point(121, 334);
            this.sotring.Name = "sotring";
            this.sotring.Size = new System.Drawing.Size(86, 31);
            this.sotring.TabIndex = 5;
            this.sotring.Text = "Sorting";
            this.sotring.UseVisualStyleBackColor = false;
            this.sotring.Click += new System.EventHandler(this.sotring_Click);
            // 
            // smail
            // 
            this.smail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.smail.Location = new System.Drawing.Point(213, 334);
            this.smail.Name = "smail";
            this.smail.Size = new System.Drawing.Size(125, 31);
            this.smail.TabIndex = 6;
            this.smail.Text = "最低分者";
            this.smail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(29, 83);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(309, 244);
            this.listBox1.TabIndex = 7;
            this.listBox1.MouseEnter += new System.EventHandler(this.listBox1_MouseEnter);
            this.listBox1.MouseLeave += new System.EventHandler(this.listBox1_MouseLeave);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(29, 383);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(309, 244);
            this.listBox2.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 731);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckedListBox CLB;
        private System.Windows.Forms.Button english;
        private System.Windows.Forms.Button all;
        private System.Windows.Forms.TextBox STnum;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label smail;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button sotring;
        private System.Windows.Forms.Label big;
        private System.Windows.Forms.Label Change_people;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox1;
    }
}

