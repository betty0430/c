﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rn = new Random();
        private void STnum_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(STnum.Text, out int result) || result < 0)
            {
                STnum.Text = "0";
                return;
            }
            CLB.Items.Clear();
            CLB.Items.Add("Name→ 計概 + 英文 + 國文 = 總分");
            int[,] studentscore = new int[result, 4];
            int namelange;
            string familyname;
            for (int n = 0; n <= int.Parse(STnum.Text) - 1; n++)
            {
                //name
                namelange = rn.Next(3, 8);
                familyname = ((char)(65 + rn.Next(0, 26))).ToString();
                for (int q = 1; q <= namelange; q++)
                {
                    familyname += (char)(97 + rn.Next(0, 26));
                }
                //1      2       3     0
                //計概 + 英文 + 國文 = 總分
                for (int w = 3; w >= 1; w--)
                {
                    studentscore[n, w] = rn.Next(0, 101);
                    studentscore[n, 0] += studentscore[n, w];
                }
                CLB.Items.Add($"{familyname}: {studentscore[n, 1]} + {studentscore[n, 2]} + {studentscore[n, 3]} = {studentscore[n, 0]}");
            }
        }

        private void CLB_SelectedIndexChanged(object sender, EventArgs e)
        {
            Change_people.Text = null;
            listBox1.Items.Clear();
            //物件
            foreach (string item in CLB.CheckedItems)
            {
                if (!(item.Substring(4, 1) == "→"))//Name→ 計概 + 英文 + 國文 = 總分
                {
                    listBox1.Items.Add(item);
                }
            }
            Change_people.Text = listBox1.Items.Count.ToString();
        }

        private void all_Click(object sender, EventArgs e)
        {
            //index(i)
            //不要加入第一個(計概 + 英文 + 國文 = 總分)
            for (int i = 0; i <= CLB.Items.Count - 1; i++)
            {
                CLB.SetItemChecked(i, true);
            }
        }

        private void english_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            int post1, post2, eng;
            for (int t = 1; t < CLB.Items.Count; t++)
            {
                post1 = CLB.Items[t].ToString().IndexOf("+");
                post2 = CLB.Items[t].ToString().IndexOf("+", post1 + 1);//找第二個 +
                //listBox2.Items.Add(CLB.Items[t].ToString().Substring(post1+1, post2 - post1-1));
                eng = int.Parse((CLB.Items[t].ToString().Substring(post1 + 2, post2 - (post1 + 2) - 1)));
                listBox2.Items.Add(eng);
                if (eng > 60) listBox1.Items.Add(CLB.Items[t]);
            }
        }

        private void listBox1_MouseEnter(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0) return;
            int score; string name;
            int score_position, name_position;
            int no1_score = 0; string no1_name = null;//大
            int lowest_score = 3 * 100; string lowest_name = null;//小
            for (int p = 0; p < listBox1.Items.Count; p++)
            {
                //取出總分
                score_position = listBox1.Items[p].ToString().IndexOf("=");
                score = int.Parse(listBox1.Items[p].ToString().Substring(score_position + 2));
                //+2是因為score_position是=的位子，要+1"空白"，+1總分第一個數字
                //取出姓名
                name_position = listBox1.Items[p].ToString().IndexOf(":");
                name = listBox1.Items[p].ToString().Substring(0, name_position);
                //大
                if (score > no1_score)
                {
                    no1_score = score;
                    no1_name = name;
                }
                //小
                if (score < lowest_score)
                {
                    lowest_score = score;
                    lowest_name = name;
                }
            }
            big.Text = $"{no1_name}:{no1_score}";
            smail.Text = $"{lowest_name}:{lowest_score}";
        }

        private void listBox1_MouseLeave(object sender, EventArgs e)
        {
            big.Text = "最高分者";
            smail.Text = "最低分者";
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("已無資料可移除", "提醒文字", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("請選擇移除項目", "提醒文字", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            this.Text = listBox1.SelectedIndex.ToString();
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            //如果未選擇listBox1.Items==-1
            Change_people.Text = listBox1.Items.Count.ToString();
        }


        struct namescore
        {
            public string name_3c;
            public int total;
        }
        private void sotring_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            if (listBox1.Items.Count <= 1) return;

            namescore[] ns = new namescore[listBox1.Items.Count];

            for (int p = 0; p < listBox1.Items.Count; p++)
            {
                ns[p].name_3c = listBox1.Items[p].ToString().Substring(0, listBox1.Items[p].ToString().IndexOf("="));
                ns[p].total = int.Parse(listBox1.Items[p].ToString().Substring(listBox1.Items[p].ToString().IndexOf("=") + 1));
            }

            string name_3c; int total;

            for (int u = 1; u <= listBox1.Items.Count; u++)
            {
                for (int y = 1; y <= listBox1.Items.Count - u; y++)
                {
                    if (ns[y - 1].total < ns[y].total)
                    {
                        total = ns[y - 1].total;
                        ns[y - 1].total = ns[y].total;
                        ns[y].total = total;

                        name_3c = ns[y - 1].name_3c;
                        ns[y - 1].name_3c = ns[y].name_3c;
                        ns[y].name_3c = name_3c;
                    }
                }
            }

            for (int y = 0; y < listBox1.Items.Count; y++)
            {
                listBox2.Items.Add($"{ns[y].name_3c}={ns[y].total}");
            }
        }
    }
}
