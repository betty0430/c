﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace xml_資料轉換
{
    class Program
    {
        static void Main(string[] args)
        {
            //學習的網址
            //https://ithelp.ithome.com.tw/m/articles/10295926
            XmlDocument doc = new XmlDocument();

            //1.讀取檔案路徑
            string Filename = "D:\\智邦學習\\xml_資料轉換\\xml_資料轉換\\xml\\datalist.xml";
            doc.Load(Filename);
            //讀取第一層(最外層)項目名稱students
            var itemsNode = doc.SelectSingleNode("students");
            //讀取第二層項目名稱student的內容資料
            var itemNodeList = itemsNode.SelectNodes("student");

            int numder = 1;
            string outputstring = "";
            foreach (XmlNode item in itemNodeList)
            {
                //將資料讀取出並顯示
                outputstring += "\n" + numder+".\n"
                   + "學號" + item["id"]?.InnerText+"\n"
                   + "姓名" + item["name"]?.InnerText + "\n"
                   + "班級" + item["class"]?.InnerText + "\n";
                numder++;
            }
            Console.WriteLine(outputstring);
            Console.ReadLine();
        }
    }
}
