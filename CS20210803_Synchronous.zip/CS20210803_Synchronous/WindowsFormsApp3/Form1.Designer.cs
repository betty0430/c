﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.RYG = new System.Windows.Forms.GroupBox();
            this.counter = new System.Windows.Forms.Label();
            this.G = new System.Windows.Forms.RadioButton();
            this.Y = new System.Windows.Forms.RadioButton();
            this.R = new System.Windows.Forms.RadioButton();
            this.KL = new System.Windows.Forms.GroupBox();
            this.KG = new System.Windows.Forms.RadioButton();
            this.KY = new System.Windows.Forms.RadioButton();
            this.KR = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.RYG.SuspendLayout();
            this.KL.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 14F);
            this.groupBox1.Location = new System.Drawing.Point(35, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 226);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "大學年級";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(18, 169);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(103, 28);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "畢業生";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(18, 125);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(79, 28);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "大三";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(18, 78);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(79, 28);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "大二";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(18, 34);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(103, 28);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "新鮮人";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Font = new System.Drawing.Font("新細明體", 14F);
            this.groupBox2.Location = new System.Drawing.Point(272, 38);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(201, 233);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fruit";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(22, 169);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(143, 28);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "Watermeion";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(22, 125);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(76, 28);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Kiwi";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(22, 79);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(99, 28);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Banana";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(22, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(86, 28);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Apple";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // RYG
            // 
            this.RYG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.RYG.Controls.Add(this.counter);
            this.RYG.Controls.Add(this.G);
            this.RYG.Controls.Add(this.Y);
            this.RYG.Controls.Add(this.R);
            this.RYG.Font = new System.Drawing.Font("新細明體", 14F);
            this.RYG.Location = new System.Drawing.Point(35, 311);
            this.RYG.Name = "RYG";
            this.RYG.Size = new System.Drawing.Size(200, 286);
            this.RYG.TabIndex = 1;
            this.RYG.TabStop = false;
            this.RYG.Text = "建興路";
            // 
            // counter
            // 
            this.counter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.counter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.counter.Location = new System.Drawing.Point(18, 50);
            this.counter.Name = "counter";
            this.counter.Size = new System.Drawing.Size(79, 46);
            this.counter.TabIndex = 7;
            this.counter.Text = "20";
            this.counter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G
            // 
            this.G.AutoSize = true;
            this.G.BackColor = System.Drawing.Color.Lime;
            this.G.Location = new System.Drawing.Point(18, 213);
            this.G.Name = "G";
            this.G.Size = new System.Drawing.Size(47, 28);
            this.G.TabIndex = 6;
            this.G.TabStop = true;
            this.G.Text = "G";
            this.G.UseVisualStyleBackColor = false;
            this.G.CheckedChanged += new System.EventHandler(this.G_CheckedChanged);
            // 
            // Y
            // 
            this.Y.AutoSize = true;
            this.Y.BackColor = System.Drawing.Color.Yellow;
            this.Y.Location = new System.Drawing.Point(18, 161);
            this.Y.Name = "Y";
            this.Y.Size = new System.Drawing.Size(47, 28);
            this.Y.TabIndex = 5;
            this.Y.TabStop = true;
            this.Y.Text = "Y";
            this.Y.UseVisualStyleBackColor = false;
            this.Y.CheckedChanged += new System.EventHandler(this.Y_CheckedChanged);
            // 
            // R
            // 
            this.R.AutoSize = true;
            this.R.BackColor = System.Drawing.Color.Red;
            this.R.Location = new System.Drawing.Point(18, 111);
            this.R.Name = "R";
            this.R.Size = new System.Drawing.Size(46, 28);
            this.R.TabIndex = 4;
            this.R.TabStop = true;
            this.R.Text = "R";
            this.R.UseVisualStyleBackColor = false;
            this.R.CheckedChanged += new System.EventHandler(this.R_CheckedChanged);
            // 
            // KL
            // 
            this.KL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.KL.Controls.Add(this.KG);
            this.KL.Controls.Add(this.KY);
            this.KL.Controls.Add(this.KR);
            this.KL.Font = new System.Drawing.Font("新細明體", 14F);
            this.KL.Location = new System.Drawing.Point(272, 311);
            this.KL.Name = "KL";
            this.KL.Size = new System.Drawing.Size(200, 286);
            this.KL.TabIndex = 7;
            this.KL.TabStop = false;
            this.KL.Text = "康樂路";
            // 
            // KG
            // 
            this.KG.AutoSize = true;
            this.KG.BackColor = System.Drawing.Color.Lime;
            this.KG.Enabled = false;
            this.KG.Location = new System.Drawing.Point(18, 213);
            this.KG.Name = "KG";
            this.KG.Size = new System.Drawing.Size(47, 28);
            this.KG.TabIndex = 6;
            this.KG.TabStop = true;
            this.KG.Text = "G";
            this.KG.UseVisualStyleBackColor = false;
            // 
            // KY
            // 
            this.KY.AutoSize = true;
            this.KY.BackColor = System.Drawing.Color.Yellow;
            this.KY.Enabled = false;
            this.KY.Location = new System.Drawing.Point(18, 161);
            this.KY.Name = "KY";
            this.KY.Size = new System.Drawing.Size(47, 28);
            this.KY.TabIndex = 5;
            this.KY.TabStop = true;
            this.KY.Text = "Y";
            this.KY.UseVisualStyleBackColor = false;
            // 
            // KR
            // 
            this.KR.AutoSize = true;
            this.KR.BackColor = System.Drawing.Color.Red;
            this.KR.Enabled = false;
            this.KR.Location = new System.Drawing.Point(18, 111);
            this.KR.Name = "KR";
            this.KR.Size = new System.Drawing.Size(46, 28);
            this.KR.TabIndex = 4;
            this.KR.TabStop = true;
            this.KR.Text = "R";
            this.KR.UseVisualStyleBackColor = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 635);
            this.Controls.Add(this.KL);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.RYG);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.RYG.ResumeLayout(false);
            this.RYG.PerformLayout();
            this.KL.ResumeLayout(false);
            this.KL.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox RYG;
        private System.Windows.Forms.RadioButton G;
        private System.Windows.Forms.RadioButton Y;
        private System.Windows.Forms.RadioButton R;
        private System.Windows.Forms.GroupBox KL;
        private System.Windows.Forms.RadioButton KG;
        private System.Windows.Forms.RadioButton KY;
        private System.Windows.Forms.RadioButton KR;
        private System.Windows.Forms.Label counter;
        private System.Windows.Forms.Timer timer1;
    }
}

