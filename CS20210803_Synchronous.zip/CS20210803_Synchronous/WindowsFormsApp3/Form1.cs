﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            //1.
            //if (radioButton1.Checked) this.Text = radioButton1.Text;
            //if (radioButton2.Checked) this.Text = radioButton2.Text;
            //if (radioButton3.Checked) this.Text = radioButton3.Text;
            //if (radioButton4.Checked) this.Text = radioButton4.Text;
            
            //2.
            RadioButton RB = sender as RadioButton;
            this.Text = RB.Text;
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = null;
            if (checkBox1.Checked) this.Text += checkBox1.Text + " ; ";
            if (checkBox2.Checked) this.Text += checkBox2.Text + " ; ";
            if (checkBox3.Checked) this.Text += checkBox3.Text + " ; ";
            if (checkBox4.Checked) this.Text += checkBox4.Text + " ; ";
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (int.Parse(counter.Text) == 0)
            {
                if (R.Checked)
                {
                    G.Checked = true;
                    return;
                }
                if (Y.Checked)
                {
                    R.Checked = true;
                    return;
                }
                if (G.Checked)
                {
                    Y.Checked = true;
                    return;
                }
            }
            else
            {
                counter.Text = $"{int.Parse(counter.Text)-1}";
            }
            if(R.Checked==true&& int.Parse(counter.Text) == 5)
            {
                KY.Checked = true;
            }
        }

        private void R_CheckedChanged(object sender, EventArgs e)
        {
            if (R.Checked)
            {
                counter.Text = "20";
                KG.Checked = true;
            }
        }

        private void Y_CheckedChanged(object sender, EventArgs e)
        {
            if (Y.Checked)
            {
                counter.Text = "5";
                KR.Checked = true;
            }
        }

        private void G_CheckedChanged(object sender, EventArgs e)
        {
            if (G.Checked)
            {
                counter.Text = "20";
                KR.Checked = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            G.Checked = true;
        }
    }
}
