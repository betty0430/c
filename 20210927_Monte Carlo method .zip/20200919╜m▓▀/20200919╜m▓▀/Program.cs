﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _20200919練習
{
    class Program
    {
        static void Main(string[] args)
        {
            PT p = new PT();
            Random rn = new Random();//8
            RandomNumberGenerator rng = new RandomNumberGenerator();
            while (true)
            {
                try
                {
                    checked
                    {
                        //亂數產生器不可相同
                        Console.Write("Input number of times for (x,y)？");
                        int n =int.Parse( Console.ReadLine());
                        double x, y;
                        int c = 0;
                        Console.WriteLine(DateTime.Now.ToLongTimeString());
                        for(int f = 1; f <= n; f++)
                        {
                            //x = rn.NextDouble();
                            //y = rn.NextDouble();
                            x = rng.Randomize();
                            y = rng.Randomize();
                            if ((x * x + y * y) <= 1) c++;
                        }

                        Console.WriteLine($"1/4 Circular area(Monte Carlo Method)：{Math.Round((double)c/n,8)}");
                        //1 / 4 Circular area(Monte Carlo Method)：0
                        Console.WriteLine($"1/4 Circular area(πr^2)：{Math.Round(Math.PI*1.0*1.0/4.0,8)}");
                        //1 / 4 Circular area(πr^2)：0.78539816
                        Console.WriteLine($"1/4 Circular area(1 / 4π)：{Math.Round(3.14159265359/4.0,8)}");
                        //1 / 4 Circular area(1 / 4π)：0.78539816
                        Console.WriteLine($"1/4 Circular area(22 / 7π)：{Math.Round((22.0/7.0)/4.0,8)}");
                        //1 / 4 Circular area(22 / 7π)：0.78571429
                        Console.WriteLine(DateTime.Now.ToLongTimeString());
                        Console.ReadKey();
                    }
                }
                catch (Exception q)
                {
                    Console.WriteLine(q);
                }
                finally
                {

                }
            }
        }
    }

    class RandomNumberGenerator
    {
        public double Randomize()
        {
            System.Threading.Thread.Sleep(1);
            double s = System.DateTime.Now.Millisecond;
            uint out1 =(uint)(s*s*s);
            //Console.WriteLine(out1);
            return double.Parse("0." + out1);
            //Console.WriteLine($"0.{outt}");
            //return 0;
        }
    }
}