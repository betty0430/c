﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void doodle(int X,int Y,string type)
        {
            Graphics graph = this.CreateGraphics();
            Random rn = new Random();
            int Width = rn.Next(50, 301);
            int Height = rn.Next(20, 201);
            //矩形
            Rectangle area = new Rectangle(X, Y, Width, Height);
            //正方形
            Rectangle square = new Rectangle(X, Y, Width, Width);
            switch (type)
            {
                case "Line":
                    graph.DrawLine(System.Drawing.Pens.Coral, 0, 0, X, Y);
                    break;
                case "Rectangle":
                    //矩形
                    //graph.DrawRectangle(Pens.Purple, X, Y, Width, Height);
                    //graph.DrawRectangle(Pens.Purple, area);
                    //正方形
                    graph.DrawRectangle(Pens.Purple, square);
                    //有顏色的正方形
                    //graph.FillRectangle(Brushes.Aquamarine, square);
                    break;
                case "Circle":
                    //隨機橢圓
                    //graph.DrawRectangle(Pens.Purple, X, Y, Width, Height);
                    //graph.DrawEllipse(Pens.Blue, X, Y, Width, Height);
                    //隨機圓型
                    //graph.DrawRectangle(Pens.Purple, X, Y, Height, Height);
                    //graph.DrawEllipse(Pens.Blue, X, Y, Height, Height);
                    //滿圓
                    //graph.DrawRectangle(Pens.Purple, X, Y, Height, Height);
                    //graph.FillEllipse(Brushes.Yellow, X, Y, Height, Height);

                    // 產生隨機圓心之圓型
                    int diameter = rn.Next(50, 300);
                    graph.DrawEllipse(Pens.Purple, X, Y, diameter, diameter);
                    X += diameter / 2;
                    Y += diameter / 2;
                    graph.DrawRectangle(Pens.Red, X, Y, diameter, diameter);
                    break;
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            doodle(e.X, e.Y, "Line");//線
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            doodle(e.X, e.Y, "Rectangle");//矩
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            doodle(e.X, e.Y, "Circle");//圓
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Refresh();
            Graphics graph = this.CreateGraphics();
            //上到下
            for (int x1 = 0; x1 <= this.Width; x1 += 30)
            {
                graph.DrawLine(Pens.DeepPink, x1, 0, x1, this.Height);
            }
            //右到左
            for (int y1 = 0; y1 <= this.Height; y1 += 30)
            {
                graph.DrawLine(Pens.GreenYellow, 0, y1, this.Width, y1);
            }
        }
    }
}
