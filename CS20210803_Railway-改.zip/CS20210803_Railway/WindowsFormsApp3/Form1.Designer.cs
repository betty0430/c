﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stop = new System.Windows.Forms.RadioButton();
            this.go = new System.Windows.Forms.RadioButton();
            this.time = new System.Windows.Forms.GroupBox();
            this.come = new System.Windows.Forms.RadioButton();
            this.pass = new System.Windows.Forms.RadioButton();
            this.back = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.time.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("新細明體", 18F);
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(26, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(466, 62);
            this.button1.TabIndex = 0;
            this.button1.Text = "模擬";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.stop);
            this.groupBox1.Controls.Add(this.go);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 18F);
            this.groupBox1.Location = new System.Drawing.Point(26, 127);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(177, 265);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "行人";
            // 
            // stop
            // 
            this.stop.AutoSize = true;
            this.stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.stop.Enabled = false;
            this.stop.Location = new System.Drawing.Point(36, 153);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(94, 34);
            this.stop.TabIndex = 1;
            this.stop.TabStop = true;
            this.stop.Text = "停步";
            this.stop.UseVisualStyleBackColor = false;
            // 
            // go
            // 
            this.go.AutoSize = true;
            this.go.BackColor = System.Drawing.Color.Aqua;
            this.go.Enabled = false;
            this.go.Location = new System.Drawing.Point(36, 78);
            this.go.Name = "go";
            this.go.Size = new System.Drawing.Size(94, 34);
            this.go.TabIndex = 0;
            this.go.TabStop = true;
            this.go.Text = "穿越";
            this.go.UseVisualStyleBackColor = false;
            this.go.Click += new System.EventHandler(this.go_Click);
            // 
            // time
            // 
            this.time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.time.Controls.Add(this.come);
            this.time.Controls.Add(this.pass);
            this.time.Controls.Add(this.back);
            this.time.Font = new System.Drawing.Font("新細明體", 18F);
            this.time.Location = new System.Drawing.Point(218, 127);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(274, 265);
            this.time.TabIndex = 2;
            this.time.TabStop = false;
            this.time.Text = "0";
            // 
            // come
            // 
            this.come.AutoSize = true;
            this.come.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.come.Enabled = false;
            this.come.Location = new System.Drawing.Point(36, 42);
            this.come.Name = "come";
            this.come.Size = new System.Drawing.Size(211, 34);
            this.come.TabIndex = 2;
            this.come.TabStop = true;
            this.come.Text = "火車將到(10s)";
            this.come.UseVisualStyleBackColor = false;
            this.come.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            this.come.Click += new System.EventHandler(this.Click1);
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.BackColor = System.Drawing.Color.Red;
            this.pass.Enabled = false;
            this.pass.Location = new System.Drawing.Point(36, 112);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(197, 34);
            this.pass.TabIndex = 3;
            this.pass.TabStop = true;
            this.pass.Text = "火車通過(5s)";
            this.pass.UseVisualStyleBackColor = false;
            this.pass.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // back
            // 
            this.back.AutoSize = true;
            this.back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.back.Enabled = false;
            this.back.Location = new System.Drawing.Point(36, 180);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(211, 34);
            this.back.TabIndex = 4;
            this.back.TabStop = true;
            this.back.Text = "火車離去(15s)";
            this.back.UseVisualStyleBackColor = false;
            this.back.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            this.back.Click += new System.EventHandler(this.Click1);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 475);
            this.Controls.Add(this.time);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.ForeColor = System.Drawing.Color.Blue;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.time.ResumeLayout(false);
            this.time.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox time;
        private System.Windows.Forms.RadioButton stop;
        private System.Windows.Forms.RadioButton go;
        private System.Windows.Forms.RadioButton come;
        private System.Windows.Forms.RadioButton pass;
        private System.Windows.Forms.RadioButton back;
        private System.Windows.Forms.Timer timer1;
    }
}

