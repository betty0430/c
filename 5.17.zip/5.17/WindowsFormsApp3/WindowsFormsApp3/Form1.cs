﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rn = new Random();
        public int number;
        private void reset_Click(object sender, EventArgs e)
        {
            number = rn.Next(0, 10);
            this.Text += number + ",";
            guess.Text = null;
            PGB.Value = 30;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PGB.Value == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("Game Over!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                PGB.PerformStep();
                counter.Text = PGB.Value.ToString();
            }
        }

        private void guess_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(guess.Text, out int result))
            {
                if (result == number)
                {
                    timer1.Enabled = false;
                    MessageBox.Show("猜對了!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        pictureBox1.Image = Resource1._1;
                        break;
                    case 1:
                        pictureBox1.Image = Resource1._2;
                        break;
                    case 2:
                        pictureBox1.Image = Resource1._3;
                        break;
                    case 3:
                        pictureBox1.Image = Resource1._4;
                        break;
                    case 4:
                        pictureBox1.Image = Resource1._5;
                        break;
                }
            }
            catch (Exception q)
            {
                MessageBox.Show(q.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void VSB_Scroll(object sender, ScrollEventArgs e)
        {
            pictureBox1.Height = VSB.Value;
            pictureBox1.Width = VSB.Value;
            this.Text = $"圖像(正方形邊長){VSB.Value}(pixels)";
        }

        private void HSB_Scroll(object sender, ScrollEventArgs e)
        {
            timer2.Interval = HSB.Value;
            this.Text = $"圖像間隔顯示速度{Math.Round((decimal)HSB.Value / 1000, 3)}秒";
        }

        int seqno = 0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            //1.亂數產生圖片
            //pictureBox1.Image = comboBox1.Items[rn.Next(0, 5)];//此方法不行
            //comboBox1.Text = comboBox1.Items[rn.Next(0, 5)].ToString();

            //2.由1-5按順序產生
            comboBox1.Text = comboBox1.Items[seqno].ToString();
            if (seqno == 4) seqno = 0;
            else seqno++;
        }

        private void stop_Click(object sender, EventArgs e)
        {
            timer2.Enabled = !timer2.Enabled;
            if (timer2.Enabled) stop.Text = "暫停";
            else stop.Text = "輪播on/off";
            //自己
            //bu1 = !bu1;
            //if (bu1 == true)
            //{
            //    timer2.Enabled = true;
            //    button1.Text = "暫停";
            //}
            //else
            //{
            //    timer2.Enabled = false;
            //    button1.Text = "輪播on/off";
            //}
        }
    }
}
