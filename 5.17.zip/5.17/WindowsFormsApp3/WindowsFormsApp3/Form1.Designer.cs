﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.reset = new System.Windows.Forms.Button();
            this.counter = new System.Windows.Forms.Label();
            this.guess = new System.Windows.Forms.TextBox();
            this.PGB = new System.Windows.Forms.ProgressBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.stop = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.VSB = new System.Windows.Forms.VScrollBar();
            this.HSB = new System.Windows.Forms.HScrollBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.PGB);
            this.panel1.Controls.Add(this.guess);
            this.panel1.Controls.Add(this.counter);
            this.panel1.Controls.Add(this.reset);
            this.panel1.Font = new System.Drawing.Font("新細明體", 12F);
            this.panel1.Location = new System.Drawing.Point(24, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(436, 120);
            this.panel1.TabIndex = 0;
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(21, 19);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(197, 41);
            this.reset.TabIndex = 0;
            this.reset.Text = "猜數字(0-9,30秒)";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // counter
            // 
            this.counter.AutoEllipsis = true;
            this.counter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.counter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.counter.Location = new System.Drawing.Point(365, 26);
            this.counter.Name = "counter";
            this.counter.Size = new System.Drawing.Size(43, 26);
            this.counter.TabIndex = 1;
            this.counter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guess
            // 
            this.guess.Location = new System.Drawing.Point(244, 26);
            this.guess.Name = "guess";
            this.guess.Size = new System.Drawing.Size(100, 31);
            this.guess.TabIndex = 2;
            this.guess.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guess.TextChanged += new System.EventHandler(this.guess_TextChanged);
            // 
            // PGB
            // 
            this.PGB.Location = new System.Drawing.Point(21, 78);
            this.PGB.Maximum = 30;
            this.PGB.Name = "PGB";
            this.PGB.Size = new System.Drawing.Size(387, 23);
            this.PGB.Step = -1;
            this.PGB.TabIndex = 3;
            this.PGB.Value = 30;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.HSB);
            this.panel2.Controls.Add(this.VSB);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.stop);
            this.panel2.Font = new System.Drawing.Font("新細明體", 12F);
            this.panel2.Location = new System.Drawing.Point(24, 161);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(620, 567);
            this.panel2.TabIndex = 4;
            // 
            // stop
            // 
            this.stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.stop.Location = new System.Drawing.Point(174, 516);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(109, 41);
            this.stop.TabIndex = 0;
            this.stop.Text = "暫停";
            this.stop.UseVisualStyleBackColor = false;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.pictureBox1.Location = new System.Drawing.Point(21, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(480, 480);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Yellow;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox1.Location = new System.Drawing.Point(21, 523);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // VSB
            // 
            this.VSB.Location = new System.Drawing.Point(534, 22);
            this.VSB.Maximum = 480;
            this.VSB.Minimum = 100;
            this.VSB.Name = "VSB";
            this.VSB.Size = new System.Drawing.Size(41, 480);
            this.VSB.TabIndex = 3;
            this.VSB.Value = 480;
            this.VSB.Scroll += new System.Windows.Forms.ScrollEventHandler(this.VSB_Scroll);
            // 
            // HSB
            // 
            this.HSB.Location = new System.Drawing.Point(322, 517);
            this.HSB.Maximum = 480;
            this.HSB.Minimum = 100;
            this.HSB.Name = "HSB";
            this.HSB.Size = new System.Drawing.Size(179, 40);
            this.HSB.TabIndex = 4;
            this.HSB.Value = 100;
            this.HSB.Scroll += new System.Windows.Forms.ScrollEventHandler(this.HSB_Scroll);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 765);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox guess;
        private System.Windows.Forms.Label counter;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.ProgressBar PGB;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.HScrollBar HSB;
        private System.Windows.Forms.VScrollBar VSB;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button stop;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}

