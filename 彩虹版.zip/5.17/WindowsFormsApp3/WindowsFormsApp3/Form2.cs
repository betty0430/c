﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Random rn = new Random();
        private void 移除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool HaveAny = true;//所有控制項
            while (HaveAny)//只要還有TextBox就要一直刪除
            {
                HaveAny = false;
                foreach(Control ctrol in this.Controls)
                {
                    if (ctrol.GetType() != typeof(MenuStrip))
                    {
                        this.Controls.Remove(ctrol);
                        HaveAny = true;
                    }
                }
            }
            this.Text = $"Number of Controls:{this.Controls.Count}";
        }
        int p;
        private void 產生ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            PictureBox BN = new PictureBox();

            BN.BackColor = Color.LightCoral;
            //出現的位置
            BN.Top = rn.Next(10, 800);
            BN.Left = rn.Next(10, 1300);
            //顯示出的長寬
            p = rn.Next(30, 250);
            BN.Width = p;
            BN.Height = p;

            this.Controls.Add(BN);

            BN.Click += new EventHandler(buttonclick);
        }
        private void buttonclick(object sender, EventArgs e)
        {
            string intput= vb.Interaction.InputBox("請輸入中文或網址","107-2Q5");
            if (intput != null)
            {
                string URL = "http://api.qrserver.com/v1/create-qr-code/?data=" + intput +
                        "&ecc=H&size=" + ((PictureBox)sender).Width + "×" + ((PictureBox)sender).Height
                        + "&bgcolor=255-255-255" + "&color=0-0-0";
                this.Text = URL;
                ((PictureBox)sender).Load(URL);
            }
            else return;
        }
    }
}
