﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GB = new System.Windows.Forms.GroupBox();
            this.CBB = new System.Windows.Forms.ComboBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // GB
            // 
            this.GB.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.GB.Controls.Add(this.pictureBox1);
            this.GB.Font = new System.Drawing.Font("新細明體", 12F);
            this.GB.ForeColor = System.Drawing.Color.Black;
            this.GB.Location = new System.Drawing.Point(26, 27);
            this.GB.Name = "GB";
            this.GB.Size = new System.Drawing.Size(438, 376);
            this.GB.TabIndex = 0;
            this.GB.TabStop = false;
            this.GB.Text = "彩虹板";
            // 
            // CBB
            // 
            this.CBB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.CBB.Font = new System.Drawing.Font("新細明體", 12F);
            this.CBB.FormattingEnabled = true;
            this.CBB.Items.AddRange(new object[] {
            "正向",
            "反向"});
            this.CBB.Location = new System.Drawing.Point(26, 448);
            this.CBB.Name = "CBB";
            this.CBB.Size = new System.Drawing.Size(438, 28);
            this.CBB.TabIndex = 1;
            this.CBB.Text = "方向";
            this.CBB.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(499, 44);
            this.vScrollBar1.Maximum = 2000;
            this.vScrollBar1.Minimum = 200;
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(35, 359);
            this.vScrollBar1.TabIndex = 2;
            this.vScrollBar1.Value = 1000;
            this.vScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar1_Scroll);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1330;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 50000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 526);
            this.Controls.Add(this.vScrollBar1);
            this.Controls.Add(this.CBB);
            this.Controls.Add(this.GB);
            this.Name = "Form1";
            this.Text = "彩虹板";
            this.toolTip1.SetToolTip(this, "Double-Click-on-Me！");
            this.TransparencyKey = System.Drawing.Color.White;
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.GB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GB;
        private System.Windows.Forms.ComboBox CBB;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

