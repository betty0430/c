﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            timer1.Interval = vScrollBar1.Value;
            this.Text = $"間隔{Math.Round(double.Parse(vScrollBar1.Value.ToString())/1000,2)}秒";
        }

        string[] colors = { "紅(Red)", "橙(Orange)", "黃(Yellow)", "綠(Green)",
                            "藍(Blue)", "靛(Indigo)", "紫(Purple)" };
        int p = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            GB.Text = colors[p];
            GB.ForeColor = Color.DarkGray;
            switch (p)
            {
                case 0:
                    GB.BackColor = Color.Red;
                    break;
                case 1:
                    GB.BackColor = Color.Orange;
                    break;
                case 2:
                    GB.BackColor = Color.Yellow;
                    break;
                case 3:
                    GB.BackColor = Color.Green;
                    break;
                case 4:
                    GB.BackColor = Color.Blue;
                    break;
                case 5:
                    GB.BackColor = Color.Indigo;
                    break;
                case 6:
                    GB.BackColor = Color.Purple;
                    break;
            }
            p = p + 1 - pt;
            if (p > 6)
            {
                p = 0;
            }
            else if (p < 0)
            {
                p = 6;
            }
        }
        int pt = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (CBB.SelectedIndex)
            {
                case 0:
                    pt = 0;
                    break;
                case 1:
                    pt = 2;
                    break;
            }
        }

        Form2 f2;
        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            f2 = new Form2();
            f2.Show();
        }
    }
}
