﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int number = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t = 0;
            show.Text = null;
            all_show = null;
            double starttime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            switch (comboBox1.SelectedIndex)
            {
                case 0://4
                    number = 4;
                    break;
                case 1://5
                    number = 5;
                    break;
                case 2://8
                    number = 8;
                    break;
                case 3://9
                    number = 9;
                    break;
                case 4://11
                    number = 11;
                    break;
            }
            box(-1, 0);
            double endtime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            all_show += "\r\n計時:" + (Math.Round(endtime - starttime, 5)).ToString() + "秒\r\n" + t + "組解";
            show.Text = all_show;
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "文字檔|*.text";
            SFD.Title = "匯出Queens";
            if (SFD.ShowDialog() == DialogResult.OK)
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(SFD.FileName, false))
                {
                    //box(-1, 0);
                    sw.WriteLine(all_show);
                }
            }
            System.Diagnostics.Process.Start(SFD.FileName);
        }

        //int q = 0;//多少皇后
        int t = 0;//第幾個
        string[,] ptbox = new string[11, 11];
        //存取q位置
        int[] xn = new int[11];
        int[] yn = new int[11];
        string all_show = null;
        private void box(int n, int z)
        {
            //顯示
            if (n == number-1)
            {
                string s = null;
                string h = null;
                for (int xpt = 0; xpt < number; xpt++)
                {
                    ptbox[xn[xpt], yn[xpt]] = "Q";
                }
                for (int x = 0; x <= number - 1; x++)
                {
                    for (int y = 0; y <= number - 1; y++)
                    {
                        //q位置
                        if (ptbox[x, y] == "Q") h += $"{y + 1}，";
                        //位置顯示
                        if (ptbox[x, y] == null) s += $"－ ";
                        else s += $"{ptbox[x, y]} ";
                    }
                    s += "\r\n";
                }
                t++;
                all_show += $"\r\n{t}. {h}\r\n{s}";

                //清除檔案
                for (int x = 0; x <= number - 1; x++)
                {
                    for (int y = 0; y <= number - 1; y++)
                    {
                        ptbox[x, y] = null;
                    }
                }
                return;
            }

            //執行
            for (int x = n+1; x <= number-1; x++)
            {
                for(int y = 0; y <= number-1; y++)
                {
                    if (pt458(x,y) == false)
                    {
                        //ptbox[x, y] = "Q";
                        xn[x] = x;
                        yn[x] = y;
                        box(x, y);
                    }
                    else if (y == number - 1)
                    {
                        //q--;
                        //ptbox[n, z] = null;
                        return;
                    }
                }
                return;
            }
        }

        private bool pt458(int x, int y)
        {
            //上下 x動
            int x1 = x;
            //上 x=0
            while (x1 > 0)
            {
                x1--;
                for(int xpt = 0; xpt < x; xpt++)
                {
                    if (x1==xn[xpt] && y==yn[xpt]) return true;
                }
            }
            //// 下 x=numder-1
            //while (x1 < number - 1)
            //{
            //    x1++;
            //    for (int xpt = 0; xpt < x; xpt++)
            //    {
            //        if (x1 == xn[xpt] && y == yn[xpt]) return true;
            //    }
            //}

            ////左右 y動
            //int x2 = x;
            //int y2 = y;
            ////左 x=0
            //while (y2 > 0)
            //{
            //    y2--;
            //    for (int xpt = 0; xpt < x; xpt++)
            //    {
            //        if (x == xn[xpt] && y2 == yn[xpt]) return true;
            //    }
            //}
            //// 右 y=number-1
            //while (y2 < number - 1)
            //{
            //    y2++;
            //    for (int xpt = 0; xpt < x; xpt++)
            //    {
            //        if (x == xn[xpt] && y2 == yn[xpt]) return true;
            //    }
            //}

            //  \
            //上 x.y-1 x=0 y=0
            int x_1 = x;
            int y_1 = y;
            while (y_1 > 0 && x_1 > 0)
            {
                //if (y_1 < 0 || x_1 < 0) break;
                x_1--; y_1--;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x_1 == xn[xpt] && y_1 == yn[xpt]) return true;
                }
                //if (ptbox[x_1, y_1] == "Q") return true;
            }

            //  /
            //上 x-1 , y+1
            int upx = x; int upy = y;
            //x為0y為3 x=0 y=number-1
            //有問題** 0,0和3,3為此物除外
            while (upx > 0 && upy < number - 1)
            {
                if (upx < 0 && upy > number - 1) break;
                upx--; upy++;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (upx == xn[xpt] && upy == yn[xpt]) return true;
                }
                if (ptbox[upx, upy] == "Q") return true;
            }
            return false;
        }
    }
}
