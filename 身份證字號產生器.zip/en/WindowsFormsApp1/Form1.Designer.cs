﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pt_in = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pt_show = new System.Windows.Forms.TextBox();
            this.pt_start = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.new_NUB = new System.Windows.Forms.TextBox();
            this.y_x = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.end = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pt_in);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pt_show);
            this.groupBox1.Controls.Add(this.pt_start);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(428, 202);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[功能一]確認現有的身分證號碼";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "請輸入身分證號碼(連同英文10碼)";
            // 
            // pt_in
            // 
            this.pt_in.Location = new System.Drawing.Point(11, 72);
            this.pt_in.MaxLength = 10;
            this.pt_in.Name = "pt_in";
            this.pt_in.Size = new System.Drawing.Size(288, 31);
            this.pt_in.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(209, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "身分證號碼之分析結果";
            // 
            // pt_show
            // 
            this.pt_show.Location = new System.Drawing.Point(11, 149);
            this.pt_show.Name = "pt_show";
            this.pt_show.ReadOnly = true;
            this.pt_show.Size = new System.Drawing.Size(391, 31);
            this.pt_show.TabIndex = 8;
            this.pt_show.Text = "欲使用本功能，請先輸入身分證字號，再按按鈕!\r\n";
            // 
            // pt_start
            // 
            this.pt_start.Location = new System.Drawing.Point(305, 72);
            this.pt_start.Name = "pt_start";
            this.pt_start.Size = new System.Drawing.Size(98, 32);
            this.pt_start.TabIndex = 2;
            this.pt_start.Text = "開始驗證S";
            this.pt_start.UseVisualStyleBackColor = true;
            this.pt_start.Click += new System.EventHandler(this.pt_start_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.new_NUB);
            this.groupBox2.Controls.Add(this.y_x);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Location = new System.Drawing.Point(13, 223);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(428, 135);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "[功能二]產生1組新的身分證字號";
            // 
            // comboBox1
            // 
            this.comboBox1.DisplayMember = "1";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "臺北市",
            "臺中市",
            "基隆市",
            "臺南市",
            "高雄市",
            "新北市",
            "宜蘭縣",
            "桃園市",
            "嘉義市",
            "新竹縣",
            "苗栗縣",
            "南投縣",
            "彰化縣",
            "新竹市",
            "雲林縣",
            "嘉義縣",
            "屏東縣",
            "花蓮縣",
            "臺東縣",
            "金門縣",
            "澎湖縣",
            "連江縣",
            "臺中縣",
            "臺南縣",
            "高雄縣",
            "陽明山"});
            this.comboBox1.Location = new System.Drawing.Point(178, 98);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(87, 99);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(70, 24);
            this.radioButton2.TabIndex = 15;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "女性";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(11, 97);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(70, 24);
            this.radioButton1.TabIndex = 14;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "男性";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // new_NUB
            // 
            this.new_NUB.Location = new System.Drawing.Point(11, 43);
            this.new_NUB.Name = "new_NUB";
            this.new_NUB.ReadOnly = true;
            this.new_NUB.Size = new System.Drawing.Size(281, 31);
            this.new_NUB.TabIndex = 7;
            this.new_NUB.Text = "請先選擇下方選項!";
            // 
            // y_x
            // 
            this.y_x.Location = new System.Drawing.Point(323, 93);
            this.y_x.Name = "y_x";
            this.y_x.Size = new System.Drawing.Size(79, 29);
            this.y_x.TabIndex = 13;
            this.y_x.Text = "剪下X";
            this.y_x.UseVisualStyleBackColor = true;
            this.y_x.Click += new System.EventHandler(this.y_x_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(323, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 29);
            this.button2.TabIndex = 3;
            this.button2.Text = "產生I";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 420);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "label4";
            // 
            // end
            // 
            this.end.Location = new System.Drawing.Point(336, 378);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(79, 29);
            this.end.TabIndex = 14;
            this.end.Text = "結束E";
            this.end.UseVisualStyleBackColor = true;
            this.end.Click += new System.EventHandler(this.end_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 449);
            this.Controls.Add(this.end);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("新細明體", 12F);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "中華民國身分證字號產生器 v3.51";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button pt_start;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox pt_in;
        private System.Windows.Forms.TextBox new_NUB;
        private System.Windows.Forms.TextBox pt_show;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button y_x;
        private System.Windows.Forms.Button end;
    }
}

