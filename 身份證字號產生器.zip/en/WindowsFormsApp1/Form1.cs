﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            one_two = 1;
        }
        Random rn = new Random();
        //結束
        private void end_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        

        //身分證
        //縣市
        string[] a_z = {"A","B","C","D","E","F","G","H","I","J","K","M","N","O","P","Q","T","U","V","W",
                        "X","Z","L","R","S","Y"};
        int[] az_NMB = { 10, 11, 12, 13, 14, 15, 16, 17, 34, 18, 19, 21, 22, 35, 23, 24, 27, 28,29, 32,
            30 , 33, 20, 25, 26, 31 };
        string[] az_ss = {"臺北市","臺中市","基隆市","臺南市","高雄市","新北市","宜蘭縣","桃園市",
                          "嘉義市","新竹縣","苗栗縣","南投縣","彰化縣","新竹市","雲林縣","嘉義縣",
                          "屏東縣","花蓮縣","臺東縣","金門縣","澎湖縣","連江縣","臺中縣","臺南縣",
                          "高雄縣","陽明山" };
        //縣市
        int ss = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ss = comboBox1.SelectedIndex;
        }
        //性別
        int one_two = 0;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            one_two = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            one_two = 2;
        }

        private void pt_start_Click(object sender, EventArgs e)
        {
            if(pt_in.Text.Length==10)
            {
                int r = 0;//總計
                //縣市
                //找縣市
                int y = 0;
                int sspt = 0;
                while (y >= 0)
                {
                    if(pt_in.Text.Substring(0, 1) == a_z[y])
                    {
                        sspt = y;
                        break;
                    }
                    y++;
                }
                r += az_NMB[sspt] / 10;
                r += (az_NMB[sspt] % 10) * 9;
                //後8碼
                int t = 8;
                for (int w = 1; w < 10; w++)
                {
                    r += int.Parse(pt_in.Text.Substring(w, 1)) * t;
                    t--;
                }
                r += int.Parse(pt_in.Text.Substring(9, 1));
                //判斷
                if (r % 10 == 0)
                {
                    string ss = az_ss[sspt];
                    int one_two = int.Parse(pt_in.Text.Substring(1, 1));
                    string mg = null;
                    if (one_two.ToString() == "1") mg = "男生";
                    else if(one_two.ToString() == "2") mg = "女性";
                    else
                    {
                        pt_show.Text = "輸入錯誤請重新輸入";
                    }
                    pt_show.Text = $"這是正確的[{ss}] 地區[{mg}] 身份證號碼!";
                }
                else
                {
                    pt_show.Text = "這是錯誤的身份證號碼!";
                }
            }
            else
            {
                pt_show.Text = "請輸入長度為10的身分證字號";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string all_number = null;
            //縣市
            all_number += a_z[comboBox1.SelectedIndex];
            //性別
            all_number += one_two;
            //數字
            for(int p = 0; p <= 6; p++)
            {
                all_number += rn.Next(0, 10);
            }

            //判斷
            int pt_number = 0;
            pt_number += az_NMB[comboBox1.SelectedIndex] / 10 * 1;
            pt_number += az_NMB[comboBox1.SelectedIndex] % 10 * 9;
            int t = 8;
            for(int w = 1; w <= 8; w++)
            {
                pt_number += int.Parse(all_number.Substring(w , 1)) * t;
                t--;
            }
            int o = 0;
            if (pt_number % 10 != 0)
            {
                o = 10 - pt_number % 10;
                //pt_number += o;
            }

            all_number += o;
            //顯示
            new_NUB.Text =all_number;
        }

        private void y_x_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(new_NUB.Text); //將字複製到剪貼板
            //Clipboard.GetText(); //從剪貼板中獲取字
        }
    }
}
