﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace lift
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Form.CheckForIllegalCrossThreadCalls = false;
            A_1.Checked = true;
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;

            close.Checked = true;
        }
        //電梯是否要停
        bool[] dt_in = new bool[9];
        bool[] dt_out = new bool[9];

        //關門時間 threada 
        System.Threading.Thread threada,thtreadb;

        //決定上下樓
        int q = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //上下鍵變成原本顏色
            up.BackColor = Color.Silver;
            bown.BackColor = Color.Silver;
            dt_out[int.Parse(comboBox1.Text)] = true;

            if (close.Checked == true && groupBox2.Enabled == false) 
            {
                thtreadb = new System.Threading.Thread(new System.Threading.ThreadStart(closes));
                thtreadb.Start();
            }

        }

        //電梯停樓層
        int light_mg = 1;

        //上下樓
        private void up_bown_Click(object sender, EventArgs e)
        {
            //
            Button bt = sender as Button;
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("請選擇樓層", "警示");
            }
            else
            {
                int ss = int.Parse(comboBox1.Text);
                if (light_mg == ss) open.Checked = true;
                if (!(ss == 1 && bt.Text == "▼") && !(ss == 8 && bt.Text == "▲"))
                {
                    bt.BackColor = Color.White;
                }
            }
        }

        private void RB_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (int.Parse(rb.Text) != light_mg)
            {
                rb.Checked = !rb.Checked;
                //2.
                dt_in[int.Parse(rb.Text)] = !dt_in[int.Parse(rb.Text)];
            }
        }

        private void close_CheckedChanged(object sender, EventArgs e)
        {
            //電梯內是否有人(內部面板是否要開)
            if (RB_1.Checked == false && RB_2.Checked == false && RB_3.Checked == false && RB_4.Checked == false
                && RB_5.Checked == false && RB_6.Checked == false && RB_7.Checked == false && RB_8.Checked == false) 
            {
                groupBox2.Enabled = false;
            }

            if (close.Checked == true)
            {
                thtreadb = new System.Threading.Thread(new System.Threading.ThreadStart(closes));
                thtreadb.Start();
            }
            //等多久關門是否停止
            if (ptclose == true)
            {
                ptclose = false;
                threada.Abort();
            }
        }

        //是否要另一方向找要去的樓層
        bool uorb = false;

        private void closes()
        {
            //再跑樓層不可以開門
            open.Enabled = false;
            //判斷事先下還是下

            if (Math.Abs(8 - light_mg) < Math.Abs(1 - light_mg))
            {
                q = 1;
                closept();
                if (uorb == false)
                {
                    q = -1;
                    closept();
                }
            }
            else
            {
                q = -1;
                closept();

                if (uorb == false)
                {
                    q = 1;
                    closept();
                }

            }
            uorb = false;
        }

        private void closept()
        {
            int c;
            for (c = light_mg; c <= 8 && c >= 1; c += q)
            {
                if (dt_in[c] == true || dt_out[c] == true) 
                {
                    uorb = true;
                    light_go(c);
                    break;
                }
            }
        }

        //電梯所在樓層到某樓(b)
        int m = 0;
        private void light_go(int b)
        {
            
            //電梯所在樓層light_mg
            if (light_mg < b)
            {
                m = 1;//上
                up_light.Checked = true;
            }
            else
            {
                m = -1;//下
                bown_light.Checked = true;
            }

            for (int c = light_mg; ; c += m)
            {
                System.Threading.Thread.Sleep(2000);
                //顯示
                switch (c)
                {
                    case 1:
                        A_1.Checked = true;
                        if (RB_1.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_1.Checked = false;
                            open.Checked=true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 2:
                        A_2.Checked = true;
                        if (RB_2.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_2.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 3:
                        A_3.Checked = true;
                        if (RB_3.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_3.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 4:
                        A_4.Checked = true;
                        if (RB_4.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_4.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 5:
                        A_5.Checked = true;
                        if (RB_5.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_5.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 6:
                        A_6.Checked = true;
                        if (RB_6.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_6.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 7:
                        A_7.Checked = true;
                        if (RB_7.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_7.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                    case 8:
                        A_8.Checked = true;
                        if (RB_8.Checked == true || dt_in[c] == true || dt_out[c] == true)
                        {
                            dt_in[c] = false;
                            dt_out[c] = false;
                            RB_8.Checked = false;
                            open.Checked = true;
                            MessageBox.Show($"{c}樓到了");
                        }
                        break;
                }

                if (light_mg == b)
                {
                    up_light.Checked = false;
                    bown_light.Checked = false;
                    return;
                }
                light_mg += m;
            }
        }

        bool ptclose = false;
        private void open_CheckedChanged(object sender, EventArgs e)
        {
            if (open.Checked == true)
            {
                //再跑樓層不可以開門
                open.Enabled = true;
                ptclose = true;
                groupBox2.Enabled = true;
                up_light.Checked = false;
                bown_light.Checked = false;
                threada = new System.Threading.Thread(new System.Threading.ThreadStart(op_to_cls));
                threada.Start();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            thtreadb.Abort();
        }

        //判斷是否時間到要關門
        private void op_to_cls()
        {
            System.Threading.Thread.Sleep(15000);
            close.Checked = true;
            //threada.Abort();
        }
    }
}
