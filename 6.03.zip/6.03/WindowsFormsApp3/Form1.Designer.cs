﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tb1_1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tb1_2 = new System.Windows.Forms.TextBox();
            this.tb2_1 = new System.Windows.Forms.TextBox();
            this.tb1_3 = new System.Windows.Forms.TextBox();
            this.tb2_2 = new System.Windows.Forms.TextBox();
            this.tb2_3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb1_1
            // 
            this.tb1_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb1_1.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb1_1.Location = new System.Drawing.Point(47, 43);
            this.tb1_1.Name = "tb1_1";
            this.tb1_1.Size = new System.Drawing.Size(182, 31);
            this.tb1_1.TabIndex = 0;
            this.tb1_1.TextChanged += new System.EventHandler(this.tb1_1_TextChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("新細明體", 18F);
            this.label1.ForeColor = System.Drawing.Color.Fuchsia;
            this.label1.Location = new System.Drawing.Point(817, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "=";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Aqua;
            this.comboBox1.Font = new System.Drawing.Font("新細明體", 12F);
            this.comboBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "<<(Shift Left)",
            ">>(Shift Right)",
            "-(1\'s Complement)",
            "&(AND)",
            "|(OR)",
            "^(XOR)",
            "Exchange",
            "-(2\'s Complement)"});
            this.comboBox1.Location = new System.Drawing.Point(297, 46);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(191, 28);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "請選擇";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tb1_2
            // 
            this.tb1_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb1_2.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb1_2.Location = new System.Drawing.Point(560, 43);
            this.tb1_2.Name = "tb1_2";
            this.tb1_2.Size = new System.Drawing.Size(182, 31);
            this.tb1_2.TabIndex = 3;
            // 
            // tb2_1
            // 
            this.tb2_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb2_1.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb2_1.Location = new System.Drawing.Point(47, 167);
            this.tb2_1.Name = "tb2_1";
            this.tb2_1.ReadOnly = true;
            this.tb2_1.Size = new System.Drawing.Size(182, 31);
            this.tb2_1.TabIndex = 4;
            // 
            // tb1_3
            // 
            this.tb1_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb1_3.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb1_3.Location = new System.Drawing.Point(951, 43);
            this.tb1_3.Name = "tb1_3";
            this.tb1_3.Size = new System.Drawing.Size(182, 31);
            this.tb1_3.TabIndex = 5;
            // 
            // tb2_2
            // 
            this.tb2_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb2_2.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb2_2.Location = new System.Drawing.Point(560, 167);
            this.tb2_2.Name = "tb2_2";
            this.tb2_2.ReadOnly = true;
            this.tb2_2.Size = new System.Drawing.Size(182, 31);
            this.tb2_2.TabIndex = 6;
            // 
            // tb2_3
            // 
            this.tb2_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb2_3.Font = new System.Drawing.Font("新細明體", 12F);
            this.tb2_3.Location = new System.Drawing.Point(951, 167);
            this.tb2_3.Name = "tb2_3";
            this.tb2_3.ReadOnly = true;
            this.tb2_3.Size = new System.Drawing.Size(182, 31);
            this.tb2_3.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 263);
            this.Controls.Add(this.tb2_3);
            this.Controls.Add(this.tb2_2);
            this.Controls.Add(this.tb1_3);
            this.Controls.Add(this.tb2_1);
            this.Controls.Add(this.tb1_2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb1_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb1_1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox tb1_2;
        private System.Windows.Forms.TextBox tb2_1;
        private System.Windows.Forms.TextBox tb1_3;
        private System.Windows.Forms.TextBox tb2_2;
        private System.Windows.Forms.TextBox tb2_3;
    }
}

