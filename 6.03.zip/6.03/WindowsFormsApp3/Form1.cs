﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tb1_1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                checked
                {
                    //2.
                    //判斷是哪一個(tb1_1到3)
                    byte p = 0;
                    if (((TextBox)sender).Name == "tb1_1") p = byte.Parse(tb1_1.Text);
                    else if (((TextBox)sender).Name == "tb1_2") p = byte.Parse(tb1_2.Text);
                    else if (((TextBox)sender).Name == "tb1_3") p = byte.Parse(tb1_3.Text);

                    //計算
                    byte tb = p; string td = null;
                    for (byte i = 0; i < 8; i++)
                    {
                        td = tb % 2 + td;
                        //tb = (byte)(tb / 2);
                        tb = (byte)(tb >> 1);
                    }

                    //如何顯示
                    switch (((TextBox)sender).Name)
                    {
                        case "tb1_1":
                            tb2_1.Text = td;
                            break;
                        case "tb1_2":
                            tb2_2.Text = td;
                            break;
                        case "tb1_3":
                            tb2_3.Text = td;
                            break;
                    }

                    //1.
                    //byte p = byte.Parse(tb1_1.Text);
                    //label2.Text = null;
                    //tb2_1.Clear();
                    //for (byte i = 0; i < 8; i++)
                    //{
                    //    tb2_1.Text = p % 2 + tb2_1.Text;
                    //    //p = (byte)(p / 2);
                    //    p = (byte)(p >> 1);
                    //    label2.Text += i + " . " + p +" , ";
                    //}
                }
            }
            catch (Exception q)
            {
                MessageBox.Show(q.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        tb1_3.Text = (byte.Parse(tb1_1.Text) << byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 1:
                        tb1_3.Text = (byte.Parse(tb1_1.Text) >> byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 2:
                        //-(1's Complement)一的補述  ex:0000111變成1111000
                        string p = null; string t = null;
                        for (int n = 0; n < tb2_1.Text.Length; n++)
                        {
                            t = tb2_1.Text.Substring(n, 1);
                            if (t == "0") p += "1";
                            else if (t == "1") p += "0";
                        }
                        tb2_3.Text = p;
                        break;
                    case 3:
                        tb1_3.Text = (byte.Parse(tb1_1.Text) & byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 4:
                        tb1_3.Text = (byte.Parse(tb1_1.Text) | byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 5:
                        tb1_3.Text = (byte.Parse(tb1_1.Text) ^ byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 6:
                        //tb1_1和tb1_2交換位置不可透過第三個變數
                        tb1_1.Text = (byte.Parse(tb1_1.Text) ^ byte.Parse(tb1_2.Text)).ToString();
                        tb1_2.Text = (byte.Parse(tb1_1.Text) ^ byte.Parse(tb1_2.Text)).ToString();
                        tb1_1.Text = (byte.Parse(tb1_1.Text) ^ byte.Parse(tb1_2.Text)).ToString();
                        break;
                    case 7:
                        //-(2's Complement)是執行完-(1's Complement)在最後加上1
                        //ex:0000111變成1111001  
                        //00000000變成00000000
                        //因為-(1's Complement)=11111111
                        //-(2's Complement)=11111111+1=00000000
                        string p1 = null; string t1 = null;
                        for (int n = 0; n < tb2_1.Text.Length; n++)
                        {
                            t1 = tb2_1.Text.Substring(n, 1);
                            if (t1 == "0") p1 += "1";
                            else if (t1 == "1") p1 += "0";
                        }

                        //+1
                        int pt = int.Parse(p1) + 1;
                        string PT = pt.ToString();

                        //從尾巴開始看只要是2就要進位
                        string p2 = null; int t2 = 0;
                        int y = 0;//是否需要進位
                        for (int c = 7; c >= 0; c--)
                        {
                            t2 = int.Parse(PT.Substring(c, 1)) + y;
                            y = 0;
                            if (t2 == 2)
                            {
                                y = 1;
                                p2 = "0" + p2;//小心位子問題
                            }
                            else p2 = t2 + p2;
                        }
                        tb2_3.Text = p2;
                        break;
                }
            }
            catch (Exception q)
            {
                MessageBox.Show(q.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }
    }
}
