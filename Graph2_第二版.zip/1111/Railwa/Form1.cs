﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railwa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Refresh();
            int x = e.X;
            int y = e.Y;
            //左到右
            for(int n = 0; n <= y; n += 10)
            {
                pt(0, n, x, n, 1);
                System.Threading.Thread.Sleep(20);
            }
            for (int n = y; n <= this.Height; n += 10)
            {
                pt(x, n, this.Width, n, 1);
                System.Threading.Thread.Sleep(20);
            }
            //上到下
            for (int n = x; n <= this.Width; n += 10)
            {
                pt(n, 0, n, y, 2);
                System.Threading.Thread.Sleep(20);
            }
            for (int n = 0; n <= x; n += 10)
            {
                pt(n, y, n, this.Height, 2);
                System.Threading.Thread.Sleep(20);
            }
        }
        private void pt(int one,int two,int tree,int four,int pp)
        {
            Graphics graph = this.CreateGraphics();
            switch (pp)
            {
                case 1:
                    graph.DrawLine(Pens.Blue, one, two, tree, four);
                    break;
                case 2:
                    graph.DrawLine(Pens.Red, one, two, tree, four);
                    break;
            }
        }
        //-------------------------------------------------------------------------
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //版面配置
                if (pageSetupDialog1.ShowDialog() == DialogResult.OK)
                {
                    pageSetupDialog1.Document = printDocument1;
                    //印表機選擇
                    if (printDialog1.ShowDialog() == DialogResult.OK)
                    {
                        printDocument1.Print();
                    }
                    else return;
                }
                else return;
                OpenFileDialog OFD = new OpenFileDialog();
                OFD.Filter = "OXPS|*.oxps";
                if (OFD.ShowDialog() == DialogResult.OK)
                {
                    //打開檔案
                    System.Diagnostics.Process.Start(OFD.FileName);
                }
            }
            catch(Exception q)
            {
                MessageBox.Show(q.Message, "警訊", MessageBoxButtons.OK, MessageBoxIcon.Warning);            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //上方-
            for(int yi = 0; yi <= 600; yi += 10)
            {
                e.Graphics.DrawLine(Pens.Blue, 0, yi, 420, yi);
            }
            //下方-
            for (int yi = 600; yi <= 1200; yi += 10)
            {
                e.Graphics.DrawLine(Pens.Green, 420, yi, 840, yi);
            }
            //上方|
            for (int xi = 420; xi <= 840; xi += 10)
            {
                e.Graphics.DrawLine(Pens.Red, xi, 0, xi, 600);
            }
            //上方|
            for (int xi = 0; xi <= 420; xi += 10)
            {
                e.Graphics.DrawLine(Pens.Pink, xi, 600, xi, 1200);
            }

            //圖形
            Rectangle area = new Rectangle(320, 500, 200, 200);
            //圓的圈
            e.Graphics.DrawRectangle(Pens.DarkRed, area);
            //畫圓形(圓的內部有顏色的)
            e.Graphics.FillEllipse(Brushes.DarkRed, area);
            
            //自行選擇
            FontDialog FD = new FontDialog();
            if (FD.ShowDialog() == DialogResult.OK)
            {
                e.Graphics.DrawString("明新科技大學資管系", FD.Font, Brushes.Coral, 10, 600);
                //                                          設定字型  文字顏色      (x.y)字型出現位置
            }
        }
    }

}


