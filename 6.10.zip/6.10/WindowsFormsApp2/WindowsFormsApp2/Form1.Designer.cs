﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textbox = new System.Windows.Forms.TextBox();
            this.PTB = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PTB)).BeginInit();
            this.SuspendLayout();
            // 
            // textbox
            // 
            this.textbox.Font = new System.Drawing.Font("新細明體", 18F);
            this.textbox.Location = new System.Drawing.Point(26, 28);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(460, 43);
            this.textbox.TabIndex = 0;
            this.textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textbox.DoubleClick += new System.EventHandler(this.input_DoubleClick);
            // 
            // PTB
            // 
            this.PTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.PTB.Location = new System.Drawing.Point(26, 86);
            this.PTB.Name = "PTB";
            this.PTB.Size = new System.Drawing.Size(370, 370);
            this.PTB.TabIndex = 1;
            this.PTB.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("新細明體", 18F);
            this.button1.Location = new System.Drawing.Point(26, 475);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(220, 38);
            this.button1.TabIndex = 2;
            this.button1.Text = "Color QR-Code";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button2.Font = new System.Drawing.Font("新細明體", 18F);
            this.button2.Location = new System.Drawing.Point(266, 475);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(220, 38);
            this.button2.TabIndex = 3;
            this.button2.Text = "Wed API";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("新細明體", 18F);
            this.button3.Location = new System.Drawing.Point(266, 536);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(220, 35);
            this.button3.TabIndex = 4;
            this.button3.Text = "With LOGO";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(447, 98);
            this.vScrollBar1.Maximum = 370;
            this.vScrollBar1.Minimum = 50;
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(39, 358);
            this.vScrollBar1.TabIndex = 5;
            this.vScrollBar1.Value = 370;
            this.vScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar1_Scroll);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 614);
            this.Controls.Add(this.vScrollBar1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.PTB);
            this.Controls.Add(this.textbox);
            this.Font = new System.Drawing.Font("新細明體", 9F);
            this.Name = "Form1";
            this.Text = "109-2 QR-Code";
            ((System.ComponentModel.ISupportInitialize)(this.PTB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textbox;
        private System.Windows.Forms.PictureBox PTB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Timer timer1;
    }
}

