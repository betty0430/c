﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using vb = Microsoft.VisualBasic;
using MessagingToolkit.QRCode.Codec.Data;
using MessagingToolkit.QRCode.Codec;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rn = new Random();
        int secore, time;
        private void input_DoubleClick(object sender, EventArgs e)
        {
            if(int.TryParse(vb.Interaction.InputBox("請輸入秒數", "cs20210616 QR-Code"),out time))
            {
                secore = 1;
                this.Text = System.DateTime.Now.ToString();
                timer1.Enabled = true;
            }
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            PTB.Width = vScrollBar1.Value;
            PTB.Height = vScrollBar1.Value;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ColorDialog cd = new ColorDialog();
                string bg, fg;
                MessageBox.Show("請選擇背景顏色", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Question);
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    bg = $"{cd.Color.R.ToString()}-{cd.Color.G.ToString()}-{cd.Color.B.ToString()}";
                }
                else return;
                MessageBox.Show("請選擇前景顏色", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Question);
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    fg = $"{cd.Color.R.ToString()}-{cd.Color.G.ToString()}-{cd.Color.B.ToString()}";
                }
                else return;
                int Size = int.Parse(vb.Interaction.InputBox("請輸入Pixel Size", "QR-Code畫素"));
                string URL = "http://api.qrserver.com/v1/create-qr-code/?data=" + textbox.Text +
                    "&ecc=H&size=" + Size + "×" + Size + "&bgcolor=" + bg + "&color=" + fg;
                this.Text = URL;
                PTB.Load(URL);
            }
            catch(Exception q)
            {
                MessageBox.Show(q.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                //1.xDialog(宣告Dialog)
                OpenFileDialog OFD = new OpenFileDialog();//讀入照片
                OFD.Title = "Load a Logo File";
                SaveFileDialog SFD = new SaveFileDialog();//讀出QR Code
                SFD.Title = "Save QR Code with Load a Logo File";
                ColorDialog cd = new ColorDialog();//選擇顏色
                //2.製作QR Code編碼器(像Random)-設定屬性
                //https://www.nuget.org/packages/MessagingToolkit.QRCode/
                MessagingToolkit.QRCode.Codec.QRCodeEncoder QRCEncoder = new QRCodeEncoder();
                QRCEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.H;
                QRCEncoder.QRCodeScale = 15;
                MessageBox.Show("請選擇背景顏色");
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    QRCEncoder.QRCodeBackgroundColor = cd.Color;
                }
                else return;
                MessageBox.Show("請選擇前景顏色");
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    QRCEncoder.QRCodeForegroundColor = cd.Color;
                }
                else return;
                //3.create a QR-Code(產生QR-Code)
                Bitmap BM = QRCEncoder.Encode(textbox.Text, Encoding.UTF8);

                //4.Load logo file into a image把要顯示的資料、照片和QR-Code和在一起
                System.Drawing.Image LOGO;
                if (OFD.ShowDialog() == DialogResult.OK)
                {
                    LOGO = Image.FromFile(OFD.FileName);
                }
                else return;

                //5.Declare & Set a Graphics from a Bitmap (QR-Code)
                System.Drawing.Graphics g = Graphics.FromImage(BM);

                //6.Locate the LOGO Image on the QR-Code(把QR-Code和圖片結合)
                int left = (PTB.Width / 2) - (LOGO.Width / 2);
                int top = (PTB.Height / 2) - (LOGO.Height / 2);
                g.DrawImage(LOGO, new Point(left, top));
                g.DrawImage(LOGO, new Point(PTB.Width - LOGO.Width, PTB.Height - LOGO.Height));

                //7.Save QR-Code with logoto a picture file
                if (SFD.ShowDialog() == DialogResult.OK)
                {
                    BM.Save(SFD.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    PTB.ImageLocation = SFD.FileName;
                    System.Diagnostics.Process.Start(SFD.FileName);
                }
            }
            catch (Exception q)
            {
                MessageBox.Show(q.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            secore++;
            if (secore > time) timer1.Enabled = false;
            textbox.Text = System.DateTime.Now.ToString();
        }
    }
}
