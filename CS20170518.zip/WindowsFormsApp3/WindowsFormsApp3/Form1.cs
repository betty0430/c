﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CLU_CheckedChanged(object sender, EventArgs e)
        {
            if (CLU.Checked)
            {
                NUD_CLU.Visible = true;
                CLU_Price.Visible = true;
            }
            else
            {
                NUD_CLU.Visible = false;
                CLU_Price.Visible = false;
            }
        }

        private void LCD_CheckedChanged(object sender, EventArgs e)
        {
            if (LCD.Checked)
            {
                NUD_LCD.Visible = true;
                LCD_Price.Visible = true;
            }
            else
            {
                NUD_LCD.Visible = false;
                LCD_Price.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Receipt.Items.Clear();
            if ((!CLU.Checked) && (!LCD.Checked)) return;

            Receipt.Items.Add($"發票日期{DTP.Value}");
            Receipt.Items.Add("");

            decimal CLU_total = 0;
            if (CLU.Checked)
            {
                CLU_total = NUD_CLU.Value * CLU_Price.Value;
                Receipt.Items.Add($"CLU({NUD_CLU.Value})顆:NT${CLU_total}");
            }

            int LCD_total = 0;
            if (LCD.Checked)
            {
                LCD_total = (int)NUD_LCD.Value * (int)LCD_Price.Value;
                Receipt.Items.Add($"LCD({NUD_LCD.Value})顆:NT${LCD_total}");
            }

            Receipt.Items.Add($"========================");
            Receipt.Items.Add($"總價:NT${CLU_total+ LCD_total}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            monthCalendar1.CalendarDimensions = new System.Drawing.Size(2, 1);
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            //1.購票日期 >= 今日
            if (monthCalendar1.SelectionStart < System.DateTime.Today|| monthCalendar1.SelectionEnd < System.DateTime.Today)
            {
                MessageBox.Show("設定[購票日期 >= 今日]", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                monthCalendar1.SelectionStart = System.DateTime.Today;
                monthCalendar1.SelectionEnd = System.DateTime.Today;
                return;
            }
            if (startdata.Checked) startdata_show.Value = monthCalendar1.SelectionStart;
            if (enddata.Checked) enddata_show.Value = monthCalendar1.SelectionEnd;

            //2.迄日>=起日
            if(startdata_show.Value >= enddata_show.Value)
            {
                MessageBox.Show("迄日>=起日且使用期限一周內", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                monthCalendar1.SetDate(System.DateTime.Today);
                startdata_show.Value = System.DateTime.Today;
                enddata_show.Value = DateTime.Today;
            }
        }

        private void cyear_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch(Exception q)
            {
                MessageBox.Show(q.Message);
            }
            finally
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            double u = 0;
            int year = monthCalendar1.SelectionStart.Year - monthCalendar1.SelectionEnd.Year;
            //年季月週日小時
            switch (comboBox1.SelectedItem)
            {
                case 0:
                    MessageBox.Show($"{year}年", "日期差距", MessageBoxButtons.OK);
                    break;
                case 1:
                    int gi;
                    if (year != 0)
                    {
                        u = 11 - monthCalendar1.SelectionStart.Year + (year - 1) * 12 + monthCalendar1.SelectionEnd.Month;
                    }
                    else
                    {
                        u = monthCalendar1.SelectionEnd.Month - monthCalendar1.SelectionStart.Month;
                    }
                    u = u % 3;
                    if (u != 0) gi = (int)u / 3 + 1;
                    else gi = (int)u / 3;
                    MessageBox.Show($"{gi}季", "日期差距", MessageBoxButtons.OK);
                    break;
                case 2:
                    if (year != 0)
                    {
                        u = 11 - monthCalendar1.SelectionStart.Year + (year - 1) * 12 + monthCalendar1.SelectionEnd.Month;
                    }
                    else
                    {
                        u = monthCalendar1.SelectionEnd.Month - monthCalendar1.SelectionStart.Month;
                    }
                    MessageBox.Show($"{u}月", "日期差距", MessageBoxButtons.OK);
                    break;
                case 3:
                    //monthCalendar1.ShowWeekNumbers
                    //MessageBox.Show($"{u}週", "日期差距", MessageBoxButtons.OK);
                    break;
                case 4:
                    break;
                case 5:
                    break;
            }
        }
    }
}
