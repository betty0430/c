﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.DTP = new System.Windows.Forms.DateTimePicker();
            this.Receipt = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LCD = new System.Windows.Forms.CheckBox();
            this.NUD_LCD = new System.Windows.Forms.NumericUpDown();
            this.LCD_Price = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CLU = new System.Windows.Forms.CheckBox();
            this.CLU_Price = new System.Windows.Forms.NumericUpDown();
            this.NUD_CLU = new System.Windows.Forms.NumericUpDown();
            this.startdata = new System.Windows.Forms.RadioButton();
            this.enddata = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cy_tb = new System.Windows.Forms.TextBox();
            this.cyear = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SetRange = new System.Windows.Forms.Button();
            this.startdata_show = new System.Windows.Forms.DateTimePicker();
            this.enddata_show = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_LCD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LCD_Price)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CLU_Price)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_CLU)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.DTP);
            this.panel1.Controls.Add(this.Receipt);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(385, 641);
            this.panel1.TabIndex = 0;
            // 
            // DTP
            // 
            this.DTP.Font = new System.Drawing.Font("新細明體", 14F);
            this.DTP.Location = new System.Drawing.Point(23, 271);
            this.DTP.Name = "DTP";
            this.DTP.Size = new System.Drawing.Size(200, 35);
            this.DTP.TabIndex = 2;
            // 
            // Receipt
            // 
            this.Receipt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Receipt.Font = new System.Drawing.Font("新細明體", 14F);
            this.Receipt.FormattingEnabled = true;
            this.Receipt.ItemHeight = 23;
            this.Receipt.Location = new System.Drawing.Point(23, 323);
            this.Receipt.Name = "Receipt";
            this.Receipt.Size = new System.Drawing.Size(342, 303);
            this.Receipt.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 14F);
            this.groupBox1.Location = new System.Drawing.Point(23, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 228);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "購物車";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.LCD);
            this.panel2.Controls.Add(this.NUD_LCD);
            this.panel2.Controls.Add(this.LCD_Price);
            this.panel2.Font = new System.Drawing.Font("新細明體", 14F);
            this.panel2.Location = new System.Drawing.Point(16, 150);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(310, 61);
            this.panel2.TabIndex = 6;
            // 
            // LCD
            // 
            this.LCD.AutoSize = true;
            this.LCD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.LCD.Location = new System.Drawing.Point(14, 16);
            this.LCD.Name = "LCD";
            this.LCD.Size = new System.Drawing.Size(77, 28);
            this.LCD.TabIndex = 0;
            this.LCD.Text = "LCD";
            this.LCD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LCD.UseVisualStyleBackColor = false;
            this.LCD.CheckedChanged += new System.EventHandler(this.LCD_CheckedChanged);
            // 
            // NUD_LCD
            // 
            this.NUD_LCD.Location = new System.Drawing.Point(97, 16);
            this.NUD_LCD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUD_LCD.Name = "NUD_LCD";
            this.NUD_LCD.Size = new System.Drawing.Size(103, 35);
            this.NUD_LCD.TabIndex = 1;
            this.NUD_LCD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUD_LCD.Visible = false;
            // 
            // LCD_Price
            // 
            this.LCD_Price.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LCD_Price.Location = new System.Drawing.Point(206, 15);
            this.LCD_Price.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.LCD_Price.Minimum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.LCD_Price.Name = "LCD_Price";
            this.LCD_Price.Size = new System.Drawing.Size(99, 35);
            this.LCD_Price.TabIndex = 2;
            this.LCD_Price.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.LCD_Price.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(16, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 35);
            this.button1.TabIndex = 0;
            this.button1.Text = "結帳";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.CLU);
            this.panel3.Controls.Add(this.CLU_Price);
            this.panel3.Controls.Add(this.NUD_CLU);
            this.panel3.Font = new System.Drawing.Font("新細明體", 14F);
            this.panel3.Location = new System.Drawing.Point(16, 76);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(310, 65);
            this.panel3.TabIndex = 5;
            // 
            // CLU
            // 
            this.CLU.AutoSize = true;
            this.CLU.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CLU.Location = new System.Drawing.Point(14, 16);
            this.CLU.Name = "CLU";
            this.CLU.Size = new System.Drawing.Size(77, 28);
            this.CLU.TabIndex = 0;
            this.CLU.Text = "CLU";
            this.CLU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CLU.UseVisualStyleBackColor = false;
            this.CLU.CheckedChanged += new System.EventHandler(this.CLU_CheckedChanged);
            // 
            // CLU_Price
            // 
            this.CLU_Price.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.CLU_Price.Location = new System.Drawing.Point(208, 16);
            this.CLU_Price.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.CLU_Price.Minimum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.CLU_Price.Name = "CLU_Price";
            this.CLU_Price.Size = new System.Drawing.Size(99, 35);
            this.CLU_Price.TabIndex = 2;
            this.CLU_Price.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.CLU_Price.Visible = false;
            // 
            // NUD_CLU
            // 
            this.NUD_CLU.Location = new System.Drawing.Point(99, 16);
            this.NUD_CLU.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NUD_CLU.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUD_CLU.Name = "NUD_CLU";
            this.NUD_CLU.Size = new System.Drawing.Size(103, 35);
            this.NUD_CLU.TabIndex = 1;
            this.NUD_CLU.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUD_CLU.Visible = false;
            // 
            // startdata
            // 
            this.startdata.AutoSize = true;
            this.startdata.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.startdata.Location = new System.Drawing.Point(19, 33);
            this.startdata.Name = "startdata";
            this.startdata.Size = new System.Drawing.Size(79, 28);
            this.startdata.TabIndex = 0;
            this.startdata.TabStop = true;
            this.startdata.Text = "起日";
            this.startdata.UseVisualStyleBackColor = false;
            // 
            // enddata
            // 
            this.enddata.AutoSize = true;
            this.enddata.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.enddata.Location = new System.Drawing.Point(115, 33);
            this.enddata.Name = "enddata";
            this.enddata.Size = new System.Drawing.Size(79, 28);
            this.enddata.TabIndex = 1;
            this.enddata.TabStop = true;
            this.enddata.Text = "迄日";
            this.enddata.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel4.Controls.Add(this.enddata);
            this.panel4.Controls.Add(this.startdata);
            this.panel4.Font = new System.Drawing.Font("新細明體", 14F);
            this.panel4.Location = new System.Drawing.Point(430, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(226, 92);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.cy_tb);
            this.panel5.Controls.Add(this.cyear);
            this.panel5.Font = new System.Drawing.Font("新細明體", 14F);
            this.panel5.Location = new System.Drawing.Point(753, 26);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(293, 92);
            this.panel5.TabIndex = 4;
            // 
            // cy_tb
            // 
            this.cy_tb.Location = new System.Drawing.Point(164, 28);
            this.cy_tb.Name = "cy_tb";
            this.cy_tb.Size = new System.Drawing.Size(100, 35);
            this.cy_tb.TabIndex = 1;
            // 
            // cyear
            // 
            this.cyear.Location = new System.Drawing.Point(15, 28);
            this.cyear.Name = "cyear";
            this.cyear.Size = new System.Drawing.Size(128, 35);
            this.cyear.TabIndex = 0;
            this.cyear.Text = "選擇年代";
            this.cyear.UseVisualStyleBackColor = true;
            this.cyear.Click += new System.EventHandler(this.cyear_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel6.Controls.Add(this.comboBox1);
            this.panel6.Controls.Add(this.SetRange);
            this.panel6.Controls.Add(this.startdata_show);
            this.panel6.Controls.Add(this.enddata_show);
            this.panel6.Font = new System.Drawing.Font("新細明體", 14F);
            this.panel6.Location = new System.Drawing.Point(430, 440);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(616, 199);
            this.panel6.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "年",
            "季",
            "月",
            "週",
            "日",
            "小時"});
            this.comboBox1.Location = new System.Drawing.Point(249, 96);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 31);
            this.comboBox1.TabIndex = 5;
            this.comboBox1.Text = "日期差距";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // SetRange
            // 
            this.SetRange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.SetRange.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SetRange.Location = new System.Drawing.Point(249, 22);
            this.SetRange.Name = "SetRange";
            this.SetRange.Size = new System.Drawing.Size(128, 35);
            this.SetRange.TabIndex = 2;
            this.SetRange.Text = "SetRange";
            this.SetRange.UseVisualStyleBackColor = false;
            // 
            // startdata_show
            // 
            this.startdata_show.Font = new System.Drawing.Font("新細明體", 14F);
            this.startdata_show.Location = new System.Drawing.Point(21, 20);
            this.startdata_show.Name = "startdata_show";
            this.startdata_show.Size = new System.Drawing.Size(200, 35);
            this.startdata_show.TabIndex = 3;
            // 
            // enddata_show
            // 
            this.enddata_show.Font = new System.Drawing.Font("新細明體", 14F);
            this.enddata_show.Location = new System.Drawing.Point(399, 22);
            this.enddata_show.Name = "enddata_show";
            this.enddata_show.Size = new System.Drawing.Size(200, 35);
            this.enddata_show.TabIndex = 4;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Font = new System.Drawing.Font("新細明體", 14F);
            this.monthCalendar1.Location = new System.Drawing.Point(430, 149);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.ShowWeekNumbers = true;
            this.monthCalendar1.TabIndex = 6;
            this.monthCalendar1.TitleBackColor = System.Drawing.Color.White;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 666);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_LCD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LCD_Price)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CLU_Price)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_CLU)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CLU;
        private System.Windows.Forms.NumericUpDown NUD_CLU;
        private System.Windows.Forms.NumericUpDown CLU_Price;
        private System.Windows.Forms.CheckBox LCD;
        private System.Windows.Forms.NumericUpDown NUD_LCD;
        private System.Windows.Forms.NumericUpDown LCD_Price;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox Receipt;
        private System.Windows.Forms.DateTimePicker DTP;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton startdata;
        private System.Windows.Forms.RadioButton enddata;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox cy_tb;
        private System.Windows.Forms.Button cyear;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button SetRange;
        private System.Windows.Forms.DateTimePicker startdata_show;
        private System.Windows.Forms.DateTimePicker enddata_show;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}

