﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace _20200919練習
{
    class Program
    {
        static void Main(string[] args)
        {
            PT p = new PT();
            while (true)
            {
                try
                {
                    checked
                    {
                        double h = Math.Round(((double)7 / (double)3), 8);
                        Console.WriteLine(h.ToString("F5"));
                        int x = int.Parse(Console.ReadLine());
                        p.n6(x);
                        Console.WriteLine($"{p.v}");
                    }
                }
                catch (Exception q)
                {
                    Console.WriteLine(q);
                }
                finally
                {

                }
            }
        }
    }