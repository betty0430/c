﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20200919練習
{
    class PT
    {
        //題目
        //https://e-tutor.itsa.org.tw/e-Tutor/mod/programming/view.php?id=468
        public decimal v = 1;
        public void n6(int n)
        {
            if (n < 1)
            {
                return;
            }
            else
            {
                v *= n;
                n = n - 1;
                n6(n);
            }
        }
    }
}
