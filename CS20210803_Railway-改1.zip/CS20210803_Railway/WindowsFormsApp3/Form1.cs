﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int one = 1;
        bool stp = false;
        private void button1_Click(object sender, EventArgs e)
        {
            stp = !stp;
            if (stp == true)
            {
                button1.Text = "結束";

                timer1.Enabled = true;
                time.Text = $"{time1}";

                stop.Enabled = true;
                if (one != 1) stop.Enabled = false;
                go.Enabled = true;
                come.Enabled = true;
                back.Enabled = true;

                come.Checked = true;
                stop.Checked = true;
            }
            else
            {
                button1.Text = "模擬";

                time1 = 0;
                time.Text = $"{time1}";

                timer1.Enabled = false;

                one = 2;
                if (one != 1) stop.Enabled = false;
                come.Enabled = false;
                back.Enabled = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            stop.Checked = true;
            come.Checked = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (come.Checked)this.Text = "噹噹噹噹……";
            time1--;
            if (time1 < 0)
            {
                if (come.Checked)
                {
                    this.Text = null;
                    time.Text = $"{5}";
                    come.Checked = false;
                    pass.Checked = true;
                    return;
                }
                if (pass.Checked)
                {
                    time.Text = $"{15}";
                    pass.Checked = false;
                    back.Checked = true;
                    return;
                }
                if (back.Checked)
                {
                    time.Text = $"{10}";
                    back.Checked = false;
                    come.Checked = true;
                    return;
                }
            }
            time.Text = $"{time1}";
        }
        int time1 = 0;
        private void CheckedChanged(object sender, EventArgs e)
        {
            if (come.Checked)
            {
                time1 = 10;
                if (go.Checked && stp == true)
                {
                    MessageBox.Show("小心火車，停不回頭!!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    go.Checked = false; stop.Checked = true;
                }
                return;
            }
            if (pass.Checked)
            {
                time1 = 5;
                if (go.Checked && stp == true)
                {
                    timer1.Enabled = false;
                    MessageBox.Show("悲劇!……生命不能重來!!", "哀悼", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    time.Text = "0"; time1 = 0;
                    one = 2; stop.Enabled = false;
                    button1_Click(null, null);
                }
                return;
            }
            if (back.Checked) { time1 = 15;  return; }
        }

        private void go_Click(object sender, EventArgs e)
        {
            if (come.Checked)
            {
                MessageBox.Show("小心火車，停不回頭!!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                go.Checked = false; stop.Checked = true;
            }
            if (pass.Checked && stp == true)
            {
                timer1.Enabled = false;
                MessageBox.Show("悲劇!……生命不能重來!!", "哀悼", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                time.Text = "0"; time1 = 0;
                one = 2; stop.Enabled = false;
                button1_Click(null, null);
            }
        }

        private void Click1(object sender, EventArgs e)
        {
            if (come.Checked)
            {
                time.Text = $"{10}";
                return;
            }
            if (back.Checked)
            {
                time.Text = $"{15}";
                return;
            }
        }
    }
}
