﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rn = new Random();
        private void Form1_Load(object sender, EventArgs e)
        {
            string input1 = vb.Interaction.InputBox("請輸入密碼(甲(乙)月日 甲0606/乙0619)","密碼管控");
            string day = DateTime.Now.Day.ToString();//日
            string moon = DateTime.Now.Date.Month.ToString();//月
            if (moon.Length != 2) moon = "0" + moon;
            if (day.Length != 2) day = "0" + day;
            //密碼判斷
            if (!(input1.Substring(0, 1) == "甲" || input1.Substring(0, 1) == "乙"))
            {
                this.Close();
            }
            else
            {
                if (!(input1.Substring(1, 2) == moon))
                {
                    this.Close();
                }
                else
                {
                    if (!(input1.Substring(3, 2) == day))
                    {
                        this.Close();
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text==null) return;
            clb.Items.Clear();//65-90
            clb.Items.Add("身分證字號[第一碼大寫英文字母，第二碼(1)男(2)女，於者八碼(0-9)，@血型#年齡[1-105]]");
            int number =int.Parse(textBox1.Text);
            for (int n = 1; n <= number; n++)
            {
                //1
                char name = (char)(rn.Next('A', 'Z' + 1));
                //2
                int two = rn.Next(1, 3);
                //3
                string pout = null;
                for(int p = 1; p <= 8; p++)
                {
                    pout += rn.Next(0, 9);
                }
                //4
                string o = "ABO";
                string oout = null;
                bool pt1 = true;
                while (pt1==true)
                {
                    pt1 = false;
                    int x = rn.Next(0, 3);
                    int y = rn.Next(1, 3);
                    if (x == 2) y = 1;
                    oout = o.Substring(x,y);
                    if (oout == "BO") pt1 = true;
                }
                //5
                string year = null;
                year = rn.Next(1, 106).ToString();
                clb.Items.Add($"{n}.{name}{two}{pout}@{oout}#{year}");
            }
        }

        string pt_bol1 = null;//判斷血型
        bool pt_home_year = false;
        bool pt_bol2 = false;
        private void bol_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == null) return;
            pt_home_year = false;
            pt_bol2 = true;
            listBox1.Items.Clear();
            switch (bol.SelectedIndex)
            {
                case 0://A
                    pt_bol1 = "A";
                    break;
                case 1://B
                    pt_bol1 = "B";
                    break;
                case 2://AB
                    pt_bol1 = "AB";
                    break;
                case 3://O
                    pt_bol1 = "O";
                    break;
            }
            pt1(pt_bol1);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            if (textBox1.Text == null || bol.SelectedIndex < 0) return;
            pt_home_year = true;
            pt_bol2 = false;
            switch (comboBox2.SelectedIndex)
            {
                case 0:
                    pt1(pt_bol1);
                    break;
            }
        }

        private void pt1(string p1)
        {
            if (int.Parse(textBox1.Text) <= 0) return;
            for (int e = 1; e <= int.Parse(textBox1.Text); e++)
            {
                int post1 = clb.Items[e].ToString().IndexOf("@");
                int post2 = clb.Items[e].ToString().IndexOf("#");
                int post3 = clb.Items[e].ToString().IndexOf(".");
                //血
                if (clb.Items[e].ToString().Substring(post1+1, post2- post1-1) == p1)
                {
                    if (pt_home_year == true)
                    {

                        //城市
                        if (clb.Items[e].ToString().Substring(post3 + 1, 1) == "J" || clb.Items[e].ToString().Substring(post3 + 1, 1) == "O")
                        {
                            //年齡
                            if (int.Parse(clb.Items[e].ToString().Substring(post2 + 1)) <= 18)
                            {
                                listBox2.Items.Add(clb.Items[e].ToString());
                            }
                        }
                    }
                    if (pt_bol2 == true)
                    {
                        listBox1.Items.Add(clb.Items[e].ToString());
                    }
                }
            }
        }
    }
}
