﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //顯示
        public string total = null;
        public int cound = 1;
        public int[] array = new int[1000];
        public int arraynum = 0;
        //public int p = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            //TA
            int number = (int)numer.Value;
            for (int i = 2; i < number; i++)
            {
                if (number % i == 0)
                {
                    array[arraynum] = i;
                    arraynum++;
                }
            }
            target = number;
            total = $"1.\t1*{number}\r\n";
            recore(1, null, 0);
            textBox2.Text = total;
            //自己
            //textBox2.Text = null;
            //cound = 1;
            //for(p = 1; p <= numer.Value / 2; p++)
            //{
            //    if (numer.Value % p == 0)
            //    {
            //        total = null;
            //        pt((int)numer.Value / p);
            //    }
            //}
        }
        //目標值
        public int target = 0;
        
        public void recore(int now,string nowstring,int index)
        {
            if (now > target) return;
            else if(now == target)
            {
                cound++;
                total += $"{cound}.\t{nowstring}\r\n";
                return;
            }
            for(int p = index; p < arraynum; p++)
            {
                int temp = now * array[p];
                string temps;
                //顯示
                if (nowstring == null)
                {
                    temps= array[p].ToString();
                }
                else
                {
                    temps = nowstring + "*" + array[p];
                }
                recore(temp, temps, p);
            }
        }

        private void numer_KeyPress(object sender, KeyPressEventArgs e)
        {
            string p = numer.Value.ToString();
            int t = 0;
           for(int y = 0; y < p.Length; y++)
            {
                for(int pt = 0; pt <= 9; pt++)
                {
                    if (int.Parse(p.Substring(y, 1)) != pt) t++;
                }
                if (t == 9) break;
            }
        }

        //public void pt(int t)
        //{
            //自己
            //會重複相同
            //if (p == 1)
            //{
            //    textBox2.Text = $"{cound}.\t1*{numer.Value}\r\n";
            //}
            //else if (t == 1 || t == 0)
            //{
            //    cound++;
            //    textBox2.Text += $"{cound}.\t{p}{total}\r\n";
            //    total = null;
            //}
            //else
            //{
            //    for (int i = 2; i <= t; i++)
            //    {
            //        if (t % i == 0)
            //        {
            //            total += $"*{i}";
            //            pt(t / i);
            //        }
            //    }
            //}
        //}
    }
}
