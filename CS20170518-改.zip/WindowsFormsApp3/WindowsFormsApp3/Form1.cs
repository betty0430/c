﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CLU_CheckedChanged(object sender, EventArgs e)
        {
            if (CLU.Checked)
            {
                NUD_CLU.Visible = true;
                CLU_Price.Visible = true;
            }
            else
            {
                NUD_CLU.Visible = false;
                CLU_Price.Visible = false;
            }
        }

        private void LCD_CheckedChanged(object sender, EventArgs e)
        {
            if (LCD.Checked)
            {
                NUD_LCD.Visible = true;
                LCD_Price.Visible = true;
            }
            else
            {
                NUD_LCD.Visible = false;
                LCD_Price.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Receipt.Items.Clear();
            if ((!CLU.Checked) && (!LCD.Checked)) return;

            Receipt.Items.Add($"發票日期{DTP.Value}");
            Receipt.Items.Add("");

            decimal CLU_total = 0;
            if (CLU.Checked)
            {
                CLU_total = NUD_CLU.Value * CLU_Price.Value;
                Receipt.Items.Add($"CLU({NUD_CLU.Value})顆:NT${CLU_total}");
            }

            int LCD_total = 0;
            if (LCD.Checked)
            {
                LCD_total = (int)NUD_LCD.Value * (int)LCD_Price.Value;
                Receipt.Items.Add($"LCD({NUD_LCD.Value})顆:NT${LCD_total}");
            }

            Receipt.Items.Add($"========================");
            Receipt.Items.Add($"總價:NT${CLU_total+ LCD_total}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            monthCalendar1.CalendarDimensions = new System.Drawing.Size(2, 1);
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            //1.購票日期 >= 今日
            if (monthCalendar1.SelectionStart < System.DateTime.Today|| monthCalendar1.SelectionEnd < System.DateTime.Today)
            {
                MessageBox.Show("設定[購票日期 >= 今日]", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                monthCalendar1.SelectionStart = System.DateTime.Today;
                monthCalendar1.SelectionEnd = System.DateTime.Today;
                return;
            }
            if (startdata.Checked) startdata_show.Value = monthCalendar1.SelectionStart;
            if (enddata.Checked) enddata_show.Value = monthCalendar1.SelectionEnd;

            //2.迄日>=起日
            if(startdata_show.Value >= enddata_show.Value)
            {
                MessageBox.Show("迄日>=起日且使用期限一周內", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                monthCalendar1.SetDate(System.DateTime.Today);
                startdata_show.Value = System.DateTime.Today;
                enddata_show.Value = DateTime.Today;
            }
        }

        private void cyear_Click(object sender, EventArgs e)
        {
            try
            {
                //  5/1和5/14左右的日子剛好星期相連
                //  例如5/1是星期二4/14是星期一
                string dt = $"7/1/{cy_tb.Text}";
                monthCalendar1.SetDate(DateTime.Parse(dt));

                //求這一年的5/1是星期幾
                int mayone = (int)DateTime.Parse($"5/1/{cy_tb.Text}").DayOfWeek;
                DateTime mothersday= DateTime.Parse($"5/1/{cy_tb.Text}");
                DateTime[] vacations = new DateTime[1];

                //判斷是星期幾
                //2.
                switch (mayone)
                {
                    case 0:
                        mothersday = DateTime.Parse("5/8/" + cy_tb);
                        break;
                    default:
                        mothersday = DateTime.Parse($"5/{((7 - mayone + 1) + 7)}/{cy_tb.Text}");
                        break;

                }

                        //1.
                        //switch (mayone)
                        //{
                        //    case 0:
                        //        mothersday = DateTime.Parse("5/8/" + cy_tb);
                        //        break;
                        //    case 1:
                        //        mothersday = DateTime.Parse("5/14/" + cy_tb);
                        //        break;
                        //    case 2:
                        //        mothersday = DateTime.Parse("5/13/" + cy_tb);
                        //        break;
                        //    case 3:
                        //        mothersday = DateTime.Parse("5/12/" + cy_tb);
                        //        break;
                        //    case 4:
                        //        mothersday = DateTime.Parse("5/11/" + cy_tb);
                        //        break;
                        //    case 5:
                        //        mothersday = DateTime.Parse("5/10/" + cy_tb);
                        //        break;
                        //    case 6:
                        //        mothersday = DateTime.Parse("5/9/" + cy_tb);
                        //        break;
                        //}

                        vacations[0] = mothersday;
                monthCalendar1.BoldedDates = vacations;
            }
            catch(Exception q)
            {
                MessageBox.Show(q.Message,"錯誤訊息" ,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //年季月週日小時
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Year, startdata_show.Value, enddata_show.Value)}年", "日期差距", MessageBoxButtons.OK);
                    break;
                case 1:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Quarter,startdata_show.Value,enddata_show.Value)}季", "日期差距", MessageBoxButtons.OK);
                    break;
                case 2:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Month, startdata_show.Value, enddata_show.Value)}月", "日期差距", MessageBoxButtons.OK);
                    break;
                case 3:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Weekday, startdata_show.Value, enddata_show.Value)}週", "日期差距", MessageBoxButtons.OK);
                    break;
                case 4:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Day, startdata_show.Value, enddata_show.Value)}日", "日期差距", MessageBoxButtons.OK);
                    break;
                case 5:
                    MessageBox.Show($"{vb.DateAndTime.DateDiff(vb.DateInterval.Hour, startdata_show.Value, enddata_show.Value)}小時", "日期差距", MessageBoxButtons.OK);
                    break;
            }
        }

        private void SetRange_Click(object sender, EventArgs e)
        {
            if(startdata_show.Value<=enddata_show.Value)monthCalendar1.SelectionRange = new SelectionRange(startdata_show.Value, enddata_show.Value);
        }
    }
}
