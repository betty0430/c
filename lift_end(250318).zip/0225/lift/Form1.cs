﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace lift
{
    public partial class Form1 : Form
    {
        public Form1()
        {//0224
            InitializeComponent();
            Form.CheckForIllegalCrossThreadCalls = false;
            A_1.Checked = true;
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
            open.Enabled = false;
            //close.Checked = true;
        }
        //電梯是否要停
        bool[] dt_in = new bool[9];
        bool[] dt_out_up = new bool[9];
        bool[] dt_out_down = new bool[9];

        //關門時間 threada 
        System.Threading.Thread threada, thtreadb;

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //上下鍵變成原本顏色
            up.BackColor = Color.Silver;
            bown.BackColor = Color.Silver;
        }

        //電梯停樓層
        int light_mg = 1;

        bool btpt = false;

        //上下樓
        private void up_bown_Click(object sender, EventArgs e)
        {
            //
            Button bt = sender as Button;
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("請選擇樓層", "警示");
            }
            else
            {
                int ss = int.Parse(comboBox1.Text);
                //if (!(ss == 1 && bt.Text == "▼") && !(ss == 8 && bt.Text == "▲"))
                //{
                    
                //}
                bt.BackColor = Color.White;

                    if (light_mg == ss && btpt == false)
                    {
                        open.Checked = true;
                        MessageBox.Show($"{light_mg}樓到了");
                    }
                    else
                    {
                        if (bt.Text == "▲") dt_out_up[int.Parse(comboBox1.Text)] = true;
                        if (bt.Text == "▼") dt_out_down[int.Parse(comboBox1.Text)] = true;
                        if (close.Checked == true && groupBox2.Enabled == false && btpt == false)
                        {
                            btpt = true;
                            thtreadb = new System.Threading.Thread(new System.Threading.ThreadStart(closept));
                            thtreadb.Start();
                        }
                    }
            }
        }

        private void RB_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (int.Parse(rb.Text) != light_mg)
            {
                rb.Checked = !rb.Checked;
                //2.
                dt_in[int.Parse(rb.Text)] = !dt_in[int.Parse(rb.Text)];
            }
        }

        private void close_CheckedChanged(object sender, EventArgs e)
        {
            //電梯內是否有人(內部面板是否要開)
            if (RB_1.Checked == false && RB_2.Checked == false && RB_3.Checked == false && RB_4.Checked == false
                && RB_5.Checked == false && RB_6.Checked == false && RB_7.Checked == false && RB_8.Checked == false)
            {
                groupBox2.Enabled = false;
            }

            if (close.Checked == true)
            {
                btpt = true;
                thtreadb = new System.Threading.Thread(new System.Threading.ThreadStart(closept));
                thtreadb.Start();
            }
            //等多久關門是否停止
            if (ptclose == true)
            {
                ptclose = false;
                optoclspt = false;
                threada.Abort();
            }
        }

        //是否要另一方向找要去的樓層
        //bool uorb = false;

        int m = 1;
        private void closept()
        {
            for (int c1 = 1; c1 < 9; c1++) 
            {
                if (dt_in[c1] == true || dt_out_up[c1] == true || dt_out_down[c1] == true)
                {
                    light_go();
                    break;
                }
            }
            btpt = false;
        }

        private void light_go()
        {
            for (int c = light_mg; ; c += m)
            {
                if (c == 9 || c == 0)
                {
                    if (c == 9) c = 8;
                    if (c == 0) c = 1;
                    m = m * -1;
                }

                //電梯所在樓層light_mg
                if (m == 1)
                {
                    up_light.Checked = true;
                    label2.Text = "▲";
                }
                else
                {
                    bown_light.Checked = true;
                    label2.Text = "▼";
                }

                System.Threading.Thread.Sleep(2000);
                //顯示

                switch (c)
                {
                    case 1:
                        A_1.Checked = true;
                        break;
                    case 2:
                        A_2.Checked = true;
                        break;
                    case 3:
                        A_3.Checked = true;
                        break;
                    case 4:
                        A_4.Checked = true;
                        break;
                    case 5:
                        A_5.Checked = true;
                        break;
                    case 6:
                        A_6.Checked = true;
                        break;
                    case 7:
                        A_7.Checked = true;
                        break;
                    case 8:
                        A_8.Checked = true;
                        break;
                }
                light_mg = c;
                label3.Text = c.ToString();
                //if (dt_in[c] == true || (dt_out_up[c] == true && m == 1) || (dt_out_down[c] == true && m == -1))

                if (dt_in[c] == true || dt_out_up[c] == true || dt_out_down[c] == true)
                {
                    dt_in[c] = false;
                    if (m == 1) dt_out_up[c] = false;
                    else dt_out_down[c] = false;
                    switch (c)
                    {
                        case 1:
                            RB_1.Checked = false;
                            break;
                        case 2:
                            RB_2.Checked = false;
                            break;
                        case 3:
                            RB_3.Checked = false;
                            break;
                        case 4:
                            RB_4.Checked = false;
                            break;
                        case 5:
                            RB_5.Checked = false;
                            break;
                        case 6:
                            RB_6.Checked = false;
                            break;
                        case 7:
                            RB_7.Checked = false;
                            break;
                        case 8:
                            RB_8.Checked = false;
                            break;
                    }
                    open.Checked = true;
                    MessageBox.Show($"{c}樓到了");

                    //up_light.Checked = false;
                    //bown_light.Checked = false;
                    if (m == 1 && int.Parse(comboBox1.Text) == light_mg) up.BackColor = Color.Silver;
                    else if (m == -1 && int.Parse(comboBox1.Text) == light_mg) bown.BackColor = Color.Silver;
                    thtreadb.Abort();
                }
                #region 判斷是否有要去的樓層
                //*********
                int pt = 0;
                if (m == -1)//往下
                {
                    for (int c2 = light_mg - 1; c2 >= 1; c2--)
                    {
                        if (dt_out_down[c] == true || dt_in[c2] == true) pt = 1;
                    }
                    if (pt != 1) m = 1;
                    else continue;
                }
                else if (m == 1)//往上
                {
                    for (int c3 = light_mg + 1; c3 <= 8; c3++)
                    {
                        if (dt_out_up[c3] == true || dt_in[c3] == true) pt = 1;
                    }
                    if (pt != 1) m = -1;
                    else continue;
                }
                //*********
                #endregion
            }
        }


        bool ptclose = false;
        private void open_CheckedChanged(object sender, EventArgs e)
        {
            if (open.Checked == true)
            {
                //再跑樓層不可以開門
                label2.Text = "";
                ptclose = true;
                groupBox2.Enabled = true;
                up_light.Checked = false;
                bown_light.Checked = false;
                threada = new System.Threading.Thread(new System.Threading.ThreadStart(op_to_cls));
                threada.Start();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (btpt == true)
            {
                thtreadb.Abort();
            }
            if (optoclspt == true)
            {
                threada.Abort();
            }
        }
        bool optoclspt = false;

        //判斷是否時間到要關門
        private void op_to_cls()
        {
            optoclspt = true;
            System.Threading.Thread.Sleep(15000);
            close.Checked = true;
        }        
    }
}
