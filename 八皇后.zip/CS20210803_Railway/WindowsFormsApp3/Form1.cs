﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int number = 0;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t = 0;
            show.Text = null;
            double starttime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            switch (comboBox1.SelectedIndex)
            {
                case 0://4
                    number = 4;
                    break;
                case 1://5
                    number = 5;
                    break;
                case 2://8
                    number = 8;
                    break;
            }
            box(-1, 0);
            ////清除檔案
            //for (int x = 0; x <= number - 1; x++)
            //{
            //    for (int y = 0; y <= number - 1; y++)
            //    {
            //        ptbox[x, y] = null;
            //    }
            //}
            //q = 0;
            double endtime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            show.Text += "\r\n計時:"+(Math.Round(endtime - starttime,5)).ToString()+"秒\r\n"+t+"組解";
        }

        //int q = 0;//多少皇后
        int t = 0;//第幾個
        string[,] ptbox = new string[8, 8];
        //存取q位置
        int[] xn = new int[8];
        int[] yn = new int[8];

        private void box(int n, int z)
        {
            //顯示
            if (n == number-1)
            {
                string s = null;
                string h = null;
                for (int xpt = 0; xpt < number; xpt++)
                {
                    ptbox[xn[xpt], yn[xpt]] = "Q";
                }
                for (int x = 0; x <= number - 1; x++)
                {
                    for (int y = 0; y <= number - 1; y++)
                    {
                        //q位置
                        if (ptbox[x, y] == "Q") h += $"{y + 1}，";
                        //位置顯示
                        if (ptbox[x, y] == null) s += $"－ ";
                        else s += $"{ptbox[x, y]} ";
                    }
                    s += "\r\n";
                }
                t++;
                show.Text += $"\r\n{t}. {h}\r\n{s}";

                //清除檔案
                for (int x = 0; x <= number - 1; x++)
                {
                    for (int y = 0; y <= number - 1; y++)
                    {
                        ptbox[x, y] = null;
                    }
                }
                return;
            }

            //執行
            for (int x = n+1; x <= number-1; x++)
            {
                for(int y = 0; y <= number-1; y++)
                {
                    if (pt458(x,y) == false)
                    {
                        //ptbox[x, y] = "Q";
                        xn[x] = x;
                        yn[x] = y;
                        box(x, y);
                    }
                    else if (y == number - 1)
                    {
                        //q--;
                        //ptbox[n, z] = null;
                        return;
                    }
                }
                return;
            }
        }

        private bool pt458(int x, int y)
        {
            //上下 x動
            int x1 = x;
            //上 x=0
            while (x1 > 0)
            {
                x1--;
                for(int xpt = 0; xpt < x; xpt++)
                {
                    if (x1==xn[xpt] && y==yn[xpt]) return true;
                }
            }
            // 下 x=numder-1
            while (x1 < number - 1)
            {
                x1++;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x1 == xn[xpt] && y == yn[xpt]) return true;
                }
            }

            //左右 y動
            int x2 = x;
            int y2 = y;
            //左 x=0
            while (y2 > 0)
            {
                y2--;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x == xn[xpt] && y2 == yn[xpt]) return true;
                }
            }
            // 右 y=number-1
            while (y2 < number - 1)
            {
                y2++;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x == xn[xpt] && y2 == yn[xpt]) return true;
                }
            }

            //  \
            //上 x.y-1 x=0 y=0
            int x_1 = x;
            int y_1 = y;
            while (y_1 > 0 && x_1 > 0)
            {
                //if (y_1 < 0 || x_1 < 0) break;
                x_1--; y_1--;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x_1 == xn[xpt] && y_1 == yn[xpt]) return true;
                }
                //if (ptbox[x_1, y_1] == "Q") return true;
            }
            //下 x.y+1 x=number-1 y=number-1
            int x_2 = x;
            int y_2 = y;
            while (x_2 < number - 1 && y_2 < number - 1)
            {
                //if (x_2 > number - 1 || y_2 > number - 1) break;
                x_2++; y_2++;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (x_2 == xn[xpt] && y_2 == yn[xpt]) return true;
                }
            }


            //  /
            //上 x-1 , y+1
            int upx = x; int upy = y;
            //x為0y為3 x=0 y=number-1
            //有問題** 0,0和3,3為此物除外
            while (upx > 0 && upy < number - 1)
            {
                if (upx < 0 && upy > number - 1) break;
                upx--; upy++;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (upx == xn[xpt] && upy == yn[xpt]) return true;
                }
                //if (ptbox[upx, upy] == "Q") return true;
            }
            //下 x+1 , y-1 y=0 x=number-1
            //有問題** 0,0和3,3為此物除外
            int downx = x; int downy = y;
            while (downx < number - 1 && downy > 0)
            {
                if (downx > number - 1 && downy < 0) break;
                downx++; downy--;
                for (int xpt = 0; xpt < x; xpt++)
                {
                    if (downx == xn[xpt] && downy == yn[xpt]) return true;
                }
                //if (ptbox[downx, downy] == "Q") return true;
            }
            return false;
        }

        //int number = 0;
        //private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    t = 0;
        //    show.Text = null;
        //    double starttime = System.DateTime.Now.TimeOfDay.TotalSeconds;
        //    switch (comboBox1.SelectedIndex)
        //    {
        //        case 0://4
        //            number = 4;
        //            break;
        //        case 1://5
        //            number = 5;
        //            break;
        //        case 2://8
        //            number = 8;
        //            break;
        //    }
        //    for (int n1 = 0; n1 < number - 1; n1++)
        //    {
        //        box(0, n1);
        //        //清除檔案
        //        for (int x = 0; x <= number - 1; x++)
        //        {
        //            for (int y = 0; y <= number - 1; y++)
        //            {
        //                ptbox[x, y] = null;
        //            }
        //        }
        //        q = 0;
        //    }
        //    double endtime = System.DateTime.Now.TimeOfDay.TotalSeconds;
        //    show.Text += "\r\n計時:" + (Math.Round(endtime - starttime, 5)).ToString() + "秒\r\n" + t + "組解";
        //}

        //int q = 0;//
        //int t = 0;
        //string[,] ptbox = new string[8, 8];
        //private void box(int n, int z)
        //{
        //    //執行
        //    ptbox[0, z] = "Q";
        //    q++;
        //    pt458(0, z);
        //    for (int x = n + 1; x <= number - 1; x++)
        //    {
        //        for (int y = 0; y <= number - 1; y++)
        //        {
        //            if (ptbox[x, y] == null)
        //            {
        //                ptbox[x, y] = "Q";
        //                q++;
        //                pt458(x, y);
        //            }
        //        }
        //    }


        //    //顯示
        //    if (q == number)
        //    {
        //        string s = null;
        //        string h = null;
        //        for (int x = 0; x <= number - 1; x++)
        //        {
        //            for (int y = 0; y <= number - 1; y++)
        //            {
        //                if (ptbox[x, y] == "Q") h += $"{y + 1}，";
        //                if (ptbox[x, y] == null) s += $"－ ";
        //                else s += $"{ptbox[x, y]} ";
        //            }
        //            s += "\r\n";
        //        }
        //        t++;
        //        show.Text += $"\r\n{t}. {h}\r\n{s}";
        //    }
        //}

        //private void pt458(int x, int y)
        //{
        //    //上下 x動
        //    int x1 = x;
        //    //上 x=0
        //    while (x1 > 0)
        //    {
        //        x1--;
        //        if (ptbox[x1, y] == null) ptbox[x1, y] = "－";
        //    }
        //    // 下 x=numder-1
        //    while (x1 < number - 1)
        //    {
        //        x1++;
        //        if (ptbox[x1, y] == null) ptbox[x1, y] = "－";
        //    }

        //    //左右 y動
        //    int x2 = x;
        //    int y2 = y;
        //    //左 x=0
        //    while (y2 > 0)
        //    {
        //        y2--;
        //        if (ptbox[x, y2] == null) ptbox[x, y2] = "－";
        //    }
        //    // 右 y=number-1
        //    while (y2 < number - 1)
        //    {
        //        y2++;
        //        if (ptbox[x, y2] == null) ptbox[x, y2] = "－";
        //    }

        //    //  \
        //    //上 x.y-1 x=0 y=0
        //    int x_1 = x;
        //    int y_1 = y;
        //    while (y_1 > 0 && x_1 > 0)
        //    {
        //        //if (y_1 < 0 || x_1 < 0) break;
        //        x_1--; y_1--;
        //        if (ptbox[x_1, y_1] == null) ptbox[x_1, y_1] = "－";
        //    }
        //    //下 x.y+1 x=number-1 y=number-1
        //    int x_2 = x;
        //    int y_2 = y;
        //    while (x_2 < number - 1 && y_2 < number - 1)
        //    {
        //        //if (x_2 > number - 1 || y_2 > number - 1) break;
        //        x_2++; y_2++;
        //        if (ptbox[x_2, y_2] == null) ptbox[x_2, y_2] = "－";
        //    }


        //    //  /
        //    //上 x-1 , y+1
        //    int upx = 0; int upy = 1;
        //    //x為0y為3 x=0 y=number-1
        //    //有問題** 0,0和3,3為此物除外
        //    while (upx > 0 && upy < number - 1)
        //    {
        //        if (upx < 0 && upy > number - 1) break;
        //        upx--; upy++;
        //        if (ptbox[upx, upy] == null) ptbox[upx, upy] = "－";
        //    }
        //    //下 x+1 , y-1 y=0 x=number-1
        //    //有問題** 0,0和3,3為此物除外
        //    int downx = x; int downy = y;
        //    while (downx < number - 1 && downy > 0)
        //    {
        //        if (downx > number - 1 && downy < 0) break;
        //        downx++; downy--;
        //        if (ptbox[downx, downy] == null) ptbox[downx, downy] = "－";
        //    }
        //}
    }
}
