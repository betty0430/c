﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random rn = new Random();
        private void 動態產生ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //一、判斷

            //1.Class----物件
            TextBox tb1 = new TextBox();//甲班
            TextBox tb2 = new TextBox();//乙班
            FontDialog fd = new FontDialog();

            //2.Properties setting(設定屬性)
            tb1.Name = "TB1A";
            tb1.BackColor = Color.Aquamarine;
            tb1.Width = 150;
            tb1.Top = rn.Next(200, 801);//離上面多遠
            tb1.Left = rn.Next(20, 701);//離左邊多遠
            tb1.Text = "資管一甲";//所顯示
            tb1.TextAlign = HorizontalAlignment.Center;//文字置中
            if (fd.ShowDialog() == DialogResult.OK) tb1.Font = fd.Font;

            tb2.Name = "TB1B";
            tb2.BackColor = Color.Gold;
            tb2.Width = 250;
            tb2.Height = 20;
            tb2.Top = rn.Next(20, 701);//離上面多遠
            tb2.Left = rn.Next(200, 801);//離左邊多遠
            tb2.Text = "資管一乙";
            tb2.TextAlign = HorizontalAlignment.Right;//文字置右
            if (fd.ShowDialog() == DialogResult.OK) tb2.Font = fd.Font;
            //3.Event Handler(按兩下後要做的動作)
            tb1.Click += new EventHandler(TextClick);
            tb2.Click += new EventHandler(TextClick);
            //二、顯示
            //4.Add Control to Form1(如何顯示在Form1上)
            this.Controls.Add(tb1);
            //Controls就是在from中上面的控制向所形成的集合物件
            this.Controls.Add(tb2);
            this.Text = $"Number of Controls:{this.Controls.Count}";
        }

        private void TextClick(object sender, EventArgs e)
        {
            if (((TextBox)sender).Name == "TB1A") ((TextBox)sender).Text = DateTime.Now.ToLongDateString();
            if (((TextBox)sender).Name == "TB1B") ((TextBox)sender).Text = DateTime.Now.ToLongTimeString();
        }

        private void 動態移除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool HaveTB = true;
            while (HaveTB)//只要還有TextBox就要一直刪除
            {
                HaveTB = false;
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl.GetType() == typeof(TextBox))//找到一個就移除
                    {
                        this.Controls.Remove(ctrl);
                        HaveTB = true;
                    }
                }
            }
            this.Text = $"Number of Controls:{this.Controls.Count}";
        }

        private void buttonToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int number;
            if (!int.TryParse(vb.Interaction.InputBox("請輸入產生個數"), out number)) return;
            //請輸入產生個數
            for (int w = 1; w <= number; w++)
            {

                //一、判斷

                //1.Class----物件
                Button BN = new Button();

                //2.Properties setting(設定屬性)
                //框框要求
                BN.BackColor = Color.LightCoral;
                BN.Top = rn.Next(10, 800);
                BN.Left = rn.Next(10, 1300);
                BN.Width = rn.Next(50, 250);
                BN.Height = rn.Next(30, 90);
                //字體要求
                BN.Font = new Font(Font.FontFamily, 30, FontStyle.Bold);

                //3.Event Handler(按兩下後要做的動作)
                BN.Click += new EventHandler(buttonclick);
                //二、顯示
                //4.Add Control to Form1(如何顯示在Form1上)
                this.Controls.Add(BN);
            }
            this.Text = $"Number of Controls:{this.Controls.Count}";
        }
        private void buttonclick(object sender, EventArgs e)
        {
            ((Button)sender).Text = vb.Interaction.InputBox("請輸入內容");
        }

        private void 移除所有物件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool HaveAny = true;//所有控制項
            while (HaveAny)//只要還有TextBox就要一直刪除
            {
                HaveAny = false;
                foreach (Control ctrl in this.Controls)
                {
                    //如果不等於menuStrip1都要刪除
                    if (ctrl.GetType() != typeof(MenuStrip))//找到一個就移除
                    {
                        this.Controls.Remove(ctrl);
                        HaveAny = true;
                    }
                }
            }
            this.Text = $"Number of Controls:{this.Controls.Count}";
        }

        private void pictureBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //一、判斷

            //1.Class----物件
            PictureBox PB = new PictureBox();
            OpenFileDialog OFD = new OpenFileDialog();
            OFD.Filter = "BMP|*.bmp|GIF|*.gif|JPG|*.jpg|所有檔案|*.*";

            //2.Properties setting(設定屬性)
            int sizelength = rn.Next(100, 401);
            PB.Width = sizelength;
            PB.Height = sizelength;
            PB.Left = rn.Next(150, 701);
            PB.Top = rn.Next(10, 601);
            this.Text = $"影像邊長(Left，Top)={sizelength}({PB.Left}，{PB.Top})";
            PB.SizeMode = PictureBoxSizeMode.StretchImage;

            if (OFD.ShowDialog() == DialogResult.OK)
            {
                PB.ImageLocation = OFD.FileName;
                this.Controls.Add(PB);
            }
        }
    }
}
